import React from 'react';
import {FLOOR, OUTLINE, fontFamily} from '../theme';
import {between, pop, trk} from '../anim';
import {STAMPS} from '../data/timeline';
import {Stage} from '../components/Stage';
import {useT} from '../components/SceneCtx';
import {Character} from '../components/Character';
import {Bedroom, LivingRoom, MGBackground} from '../components/Backgrounds';
import {Pill, Stamp} from '../components/Overlays';
import {IconBank, IconMoon, IconPlate, IconSchool, IconSun} from '../components/Icons';
import {Plate, Remote, Spoon} from '../components/Props';

export const CROSS_L: [number, number] = [15, 93];
export const CROSS_R: [number, number] = [-15, -93];
export const CLUTCH_L: [number, number] = [15, 109];
export const CLUTCH_R: [number, number] = [-15, -100];
export const HIP_L: [number, number] = [-50, 85];

/* ---------- Scene 1 : ড্রয়িং রুমে রিমোট নিয়ে টানাটানি ---------- */
export const Scene1: React.FC = () => {
  const t = useT();
  const pleading = t >= 20.4;
  const reach: [number, number] = [88 + Math.sin(t * 7) * 3, -5];
  return (
    <>
      <Stage zoom={0.03} ox={760} oy={600}>
        <LivingRoom tv="cricket" glow={between(t, 17.7, 20.4)} />
        {between(t, 5.4, 8.8) && <circle cx={860} cy={200} r={74 + ((t * 40) % 30)} fill="none" stroke="#E53935" strokeWidth={7} opacity={0.9 - ((t * 40) % 30) / 40} />}
        <Character
          who="sajib" x={520} y={FLOOR} sit lean={-4}
          expr={pleading ? 'sad' : 'neutral'} look={[6, 0]} jitter={pleading ? 1.6 : 0.4}
          armL={CLUTCH_L} armR={CLUTCH_R}
          hold={(h) => <Remote x={(h.L.x + h.R.x) / 2} y={(h.L.y + h.R.y) / 2 - 6} rot={22} />}
        />
        <Character
          who="nusrat" x={940} y={FLOOR} flip expr={t < 5 ? 'neutral' : 'angry'}
          armR={reach} armL={HIP_L}
        />
      </Stage>
      <Pill from={5.2} to={11.0} x={330} y={86} color="#E26D5A">মিরপুর · রাত ৯টা</Pill>
      <Pill from={10.84} to={14.0} x={940} y={250} color="#43A047">নুসরাত</Pill>
      <Pill from={13.4} to={17.0} x={520} y={330} color="#1E88E5">সজীব</Pill>
    </>
  );
};

/* ---------- Scene 2 : মোশন গ্রাফিক্স — সারাদিনের ব্যস্ততা ---------- */
const InfoCard: React.FC<{cx: number; cy: number; s: number; color: string; title: string; sub: string; icon: React.ReactNode; who: 'sajib' | 'nusrat'}> = ({cx, cy, s, color, title, sub, icon, who}) => {
  if (s <= 0) return null;
  const sc = 0.8;
  return (
    <g transform={`translate(${cx} ${cy}) scale(${s})`}>
      <rect x={-340} y={-290} width={680} height={600} rx={44} fill="#FFFFFF" stroke={OUTLINE} strokeWidth={6} />
      <rect x={-340} y={-290} width={680} height={110} rx={44} fill={color} stroke={OUTLINE} strokeWidth={6} />
      <rect x={-337} y={-230} width={674} height={50} fill={color} />
      <text x={0} y={-208} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={58} fill="#fff">{title}</text>
      <g transform="translate(0 -50) scale(0.9)">{icon}</g>
      <g transform="translate(-175 0)">
        <Character who={who} x={0} y={290 + 300 * sc} scale={sc} clipY={-300} talking={false} expr="happy" />
      </g>
      <text x={125} y={190} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={50} fill={OUTLINE}>{sub}</text>
    </g>
  );
};

export const Scene2: React.FC = () => {
  const t = useT();
  const prog = trk(t, [[24.7, 0], [34.6, 1]])[0];
  const x0 = 200;
  const x1 = 1720;
  return (
    <Stage zoom={0.02}>
      <MGBackground />
      <InfoCard cx={500} cy={380} s={pop(t, 24.66, 35.3)} color="#1E88E5" title="সজীব" sub="সকালে ব্যাংক" icon={<IconBank />} who="sajib" />
      <InfoCard cx={1420} cy={380} s={pop(t, 26.7, 35.3)} color="#43A047" title="নুসরাত" sub="স্কুলে পড়ায়" icon={<IconSchool />} who="nusrat" />
      {/* day timeline */}
      <g opacity={pop(t, 28.3, 35.3) > 0 ? 1 : 0}>
        <defs>
          <linearGradient id="day" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#FFD84D" />
            <stop offset="0.55" stopColor="#F28C38" />
            <stop offset="1" stopColor="#25346E" />
          </linearGradient>
        </defs>
        <rect x={x0} y={880} width={x1 - x0} height={44} rx={22} fill="url(#day)" stroke={OUTLINE} strokeWidth={5} />
        <g transform="translate(130 902) scale(0.5)"><IconSun /></g>
        <g transform="translate(1790 902) scale(0.5)"><IconMoon /></g>
        <circle cx={x0 + (x1 - x0) * prog} cy={902} r={24} fill="#fff" stroke={OUTLINE} strokeWidth={6} />
        <text x={960} y={995} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={46} fill={OUTLINE} opacity={between(t, 29.4, 33.0) ? 1 : 0}>ফিরতে ফিরতে সন্ধ্যা পেরিয়ে যায়</text>
      </g>
      {t >= 33.0 && (
        <g transform={`translate(1590 ${760 - 10 * Math.sin(t * 6)}) scale(${pop(t, 33.0, 35.3) * 0.8})`}>
          <IconPlate />
          <text x={0} y={-120} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={60} fill="#B8453A" stroke="#fff" strokeWidth={8} paintOrder="stroke">রাতের ভাত</text>
        </g>
      )}
    </Stage>
  );
};

/* ---------- Scene 3 : থালা কোলে ভাত, রিমোট হাত বদল ---------- */
export const Scene3: React.FC = () => {
  const t = useT();
  const p = (Math.sin(t * 4) + 1) / 2;
  const eatR: [number, number] = [15 - 15 * p, 70 + 120 * p];
  const cyc = Math.max(0, (t - 41.4) / 1.35);
  const rx = t < 41.4 ? 520 : 520 + 240 * (0.5 - 0.5 * Math.cos(Math.PI * cyc));
  const ry = t < 41.4 ? 782 : 782 - 120 * Math.abs(Math.sin(Math.PI * cyc));
  const meal = (x: number, who: 'sajib' | 'nusrat') => (
    <Character
      who={who} x={x} y={FLOOR} sit expr="neutral" look={[7, 0]}
      armL={[10, 75]} armR={eatR}
      hold={(h) => (
        <>
          <Plate x={h.L.x + 26} y={h.L.y + 24} />
          <Spoon x={h.R.x} y={h.R.y - 6} rot={-95 + p * 40} />
        </>
      )}
    />
  );
  return (
    <>
      <Stage zoom={0.04} ox={600} oy={650}>
        <LivingRoom tv="cricket" />
        {meal(380, 'sajib')}
        {meal(690, 'nusrat')}
        <Remote x={rx} y={ry} rot={t < 41.4 ? 85 : 85 + cyc * 180} s={1.5} glow={t > 40.4} />
      </Stage>
      <Stamp from={STAMPS.rate.from} to={STAMPS.rate.to} x={1000} y={250} rot={-6} color="#E53935">রিমোট: সপ্তাহে ~২০০ বার হাত বদল</Stamp>
    </>
  );
};

/* ---------- Scene 4 : রিমোট বালিশের নিচে, ভালো মানুষ সেজে গোসলে ---------- */
export const Scene4: React.FC = () => {
  const t = useT();
  const [x] = trk(t, [[46.72, -160], [48.8, 640], [54.56, 640], [55.9, 290]]);
  const walking = t < 48.9 || t >= 54.56;
  const flip = t >= 54.56;
  const [a1, b1] = trk(t, [[48.9, 8, 40], [49.9, 60, 10], [51.2, 60, 10], [52.0, 60, 10]]);
  const pat = between(t, 51.98, 54.56) ? Math.sin(t * 9) * 6 : 0;
  const armR: [number, number] = t >= 54.56 ? [6, 4] : [a1 + pat, b1];
  const bump = t < 51.2 ? 0 : trk(t, [[51.2, 0], [51.7, 1]])[0];
  const doorOpen = trk(t, [[54.3, 0], [55.1, 1]])[0];
  const fade = t > 55.8 ? Math.max(0, 1 - (t - 55.8) / 0.35) : 1;
  return (
    <>
      <Stage zoom={0.035} ox={800} oy={600}>
        <Bedroom doorOpen={doorOpen} bump={bump} />
        <Character
          who="sajib" x={x} y={FLOOR} walk={walking} flip={flip} opacity={fade}
          expr={t < 48.9 ? 'neutral' : 'smug'} look={flip ? [0, 0] : [-2, 0]}
          armR={armR} towel={t >= 54.4}
          hold={(h) => (t < 51.2 && !flip ? <Remote x={h.R.x + 4} y={h.R.y - 8} rot={t < 49.9 ? 15 : 75} /> : null)}
        />
        {between(t, 53.9, 55.7) && <ellipse cx={x} cy={FLOOR - 640 + Math.sin(t * 8) * 4} rx={64} ry={15} fill="none" stroke="#F5C518" strokeWidth={9} />}
      </Stage>
      <Stamp from={STAMPS.goodMan.from} to={STAMPS.goodMan.to} x={1180} y={230} rot={5} color="#2E9E4F">ভালো মানুষ!</Stamp>
    </>
  );
};
