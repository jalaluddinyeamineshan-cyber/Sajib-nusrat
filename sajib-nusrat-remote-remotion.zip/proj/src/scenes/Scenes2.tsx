import React from 'react';
import {FLOOR} from '../theme';
import {between, pop, trk} from '../anim';
import {STAMPS} from '../data/timeline';
import {Stage} from '../components/Stage';
import {useT} from '../components/SceneCtx';
import {Character, handScreen} from '../components/Character';
import {Balcony, BalconyRail, Bedroom, LivingRoom, Rooftop, SOCKET} from '../components/Backgrounds';
import {Pill, Stamp} from '../components/Overlays';
import {IconFan, IconHorn, IconStar5} from '../components/Icons';
import {Cushion} from '../components/Props';
import {CROSS_L, CROSS_R} from './Scenes1';

/* ---------- Scene 5 : নুসরাতের খোঁজ — সোফা, টেবিল, বালিশ, প্লাগ ---------- */
const Scene5a: React.FC = () => {
  const t = useT();
  const [x] = trk(t, [[56.22, -160], [57.2, 700], [59.6, 700], [60.3, 880]]);
  const walking = t < 57.2 || between(t, 59.6, 60.3);
  const holding = between(t, 57.3, 59.6);
  const flipA = Math.cos(Math.PI * Math.max(0, Math.min(1, (t - 57.8) / 0.8)));
  const [lean, crouch] = trk(t, [[60.3, 0, 0], [60.9, 48, 40]]);
  return (
    <Stage zoom={0.04} ox={800} oy={600}>
      <LivingRoom tv="drama" table={t >= 59.6} cushionOut={holding} />
      <Character
        who="nusrat" x={x} y={FLOOR} walk={walking} lean={t > 60.3 ? lean : 0} crouch={t > 60.3 ? crouch : 0}
        expr={t < 58.7 ? 'think' : t < 60.3 ? 'surprised' : 'angry'} look={[5, 3]}
        armL={holding ? [25, 70] : [-6, -4]} armR={holding ? [-25, -70] : [6, 4]}
        hold={(h) => (holding ? <Cushion x={(h.L.x + h.R.x) / 2} y={(h.L.y + h.R.y) / 2} sx={flipA} rot={-8} fill="#4E9AAB" /> : null)}
      />
    </Stage>
  );
};

const Scene5b: React.FC = () => {
  const t = useT();
  const [x] = trk(t, [[61.36, -160], [62.9, 600]]);
  const exp = t < 64.2 ? 'neutral' : t < 65.0 ? 'surprised' : 'smug';
  const ring = between(t, 64.0, 66.74);
  return (
    <>
      <Stage zoom={0.04} ox={800} oy={600}>
        <Bedroom bump={1} />
        {ring && <ellipse cx={850} cy={548} rx={86 + 8 * Math.sin(t * 8)} ry={50} fill="none" stroke="#E53935" strokeWidth={7} />}
        <Character who="nusrat" x={x} y={FLOOR} walk={t < 62.9} expr={exp} look={[6, 2]} armR={t > 64.4 ? [62, 12] : [6, 4]} />
      </Stage>
      <Stamp from={STAMPS.weird.from} to={STAMPS.weird.to} x={1240} y={200} rot={-5} color="#E53935">অস্বাভাবিক উঁচু!</Stamp>
    </>
  );
};

const Scene5c: React.FC = () => {
  const t = useT();
  const [x] = trk(t, [[66.74, 200], [69.0, 1630], [70.4, 1630], [71.4, 1500], [73.3, 1500], [74.18, 1300]]);
  const away = t >= 73.3;
  const walking = t < 69.0 || away;
  const reach = between(t, 69.2, 72.4);
  const armR: [number, number] = reach ? [50, 30] : [6, 4];
  const armL: [number, number] = between(t, 71.4, 72.4) ? [30, 75] : [-6, -4];
  const hand = handScreen({who: 'nusrat', x, y: FLOOR, arm: [50, 30], side: 'R'});
  const plug = t < 70.3 ? SOCKET : t < 72.5 ? {x: hand.x + 16, y: hand.y} : null;
  return (
    <Stage zoom={0.04} ox={1400} oy={600}>
      <LivingRoom tv={t < 70.4 ? 'drama' : 'off'} plug={plug} coil={t >= 72.5} />
      <Character who="nusrat" x={x} y={FLOOR} walk={walking} flip={away} expr="smug" look={[5, 0]} armR={armR} armL={armL} />
    </Stage>
  );
};

export const Scene5: React.FC = () => {
  const t = useT();
  if (t < 61.36) return <Scene5a />;
  if (t < 66.74) return <Scene5b />;
  return <Scene5c />;
};

/* ---------- Scene 6 : কালো পর্দা, মান-অভিমান ---------- */
export const Scene6: React.FC = () => {
  const t = useT();
  const seated = t >= 87.16;
  const [sx] = trk(t, [[74.18, -160], [78.5, 330]]);
  const walking = t < 78.5;
  const sExpr = t < 80.7 ? 'neutral' : t < 82.6 ? 'surprised' : 'angry';
  return (
    <Stage zoom={0.04} ox={700} oy={600} shake={[[80.7, 81.4]]}>
      <LivingRoom tv="off" dim={0.16} />
      <Character who="nusrat" x={650} y={FLOOR} sit expr="angry" look={[6, 0]} jitter={0.7} armL={CROSS_L} armR={CROSS_R} />
      <Character
        who="sajib" x={sx} y={FLOOR} walk={walking} sit={seated} flip={seated} towel={!seated}
        expr={seated ? 'sad' : sExpr} look={seated ? [-6, 0] : [4, 0]} jitter={seated ? 0.6 : 0}
        armL={seated ? CROSS_L : [-6, -4]} armR={seated ? CROSS_R : [6, 4]}
      />
    </Stage>
  );
};

/* ---------- Scene 7 : নীরবতা, তারপর বারান্দা ---------- */
const Scene7a: React.FC = () => {
  const t = useT();
  const f = (t * 30) | 0;
  return (
    <Stage zoom={0.05} ox={900} oy={600}>
      <LivingRoom tv="off" dim={0.25} />
      <Character who="nusrat" x={650} y={FLOOR} sit expr="angry" look={[6, 0]} armL={CROSS_L} armR={CROSS_R} />
      <Character who="sajib" x={330} y={FLOOR} sit flip expr="sad" look={[-6, 0]} armL={CROSS_L} armR={CROSS_R} />
      {between(t, 92.9, 94.8) && (
        <g transform={`translate(1000 60)`} opacity={0.9}>
          {[0, 1, 2].map((i) => <path key={i} d={`M${-150 - i * 26} ${40 + i * 10} q${60} ${30 + ((f * 2 + i * 10) % 20)} ${120} 0`} fill="none" stroke="#fff" strokeWidth={6} strokeLinecap="round" opacity={0.8} />)}
        </g>
      )}
      {between(t, 95.1, 96.3) && (
        <g transform={`translate(250 300) scale(${pop(t, 95.1, 96.3) * 0.9})`}><IconHorn /></g>
      )}
    </Stage>
  );
};

const Scene7b: React.FC = () => {
  const t = useT();
  const open = trk(t, [[99.3, 0], [101.5, 1]])[0];
  const turn = t >= 105.0;
  const exp = t < 101.5 ? 'neutral' : t < 104 ? 'surprised' : 'happy';
  const armR: [number, number] = t < 101.5 ? [60, 12] : turn ? [30, 80] : [6, 4];
  return (
    <Stage zoom={0.04} ox={800} oy={600}>
      <Balcony open={open} />
      <Character who="sajib" x={700} y={FLOOR} flip={turn} expr={turn ? 'happy' : exp} look={turn ? [0, 0] : [3, -5]} headTilt={turn ? 0 : -8} armR={armR} />
      <BalconyRail />
    </Stage>
  );
};

export const Scene7: React.FC = () => {
  const t = useT();
  return t < 99.3 ? <Scene7a /> : <Scene7b />;
};

/* ---------- Scene 8 : ছাদে তারা দেখা ---------- */
export const Scene8: React.FC = () => {
  const t = useT();
  const [nx] = trk(t, [[108.1, -160], [110.4, 1250]]);
  const nSit = t >= 110.5;
  const [sx] = trk(t, [[110.6, -160], [112.6, 1030]]);
  const sSit = t >= 112.7;
  const pointing = t >= 112.92;
  const star = pop(t, 112.9, 119.16) || (t > 119 ? 1 : 0);
  return (
    <>
      <Stage zoom={0.045} ox={1300} oy={500}>
        <Rooftop />
        <Character who="nusrat" x={nSit ? 1250 : nx} y={FLOOR} walk={!nSit} sit={nSit} shawl={t >= 109.6} expr="happy" look={[3, -5]} headTilt={nSit ? -6 : 0} armL={nSit ? CROSS_L : [-6, -4]} armR={nSit ? CROSS_R : [6, 4]} />
        {t >= 110.6 && (
          <Character who="sajib" x={sSit ? 1030 : sx} y={FLOOR} walk={!sSit} sit={sSit} expr="happy" look={pointing ? [4, -5] : [0, 0]} armR={pointing ? [132, 0] : [6, 4]} />
        )}
        {pointing && (
          <g transform={`translate(1580 170) scale(${(1 + 0.12 * Math.sin(t * 6)) * Math.min(1, star + 0.01)})`}>
            {Array.from({length: 8}).map((_, i) => <line key={i} x1={0} y1={-100} x2={0} y2={-130} transform={`rotate(${i * 45})`} stroke="#FFE066" strokeWidth={8} strokeLinecap="round" />)}
            <IconStar5 />
          </g>
        )}
      </Stage>
      <Pill from={108.5} to={112.4} x={330} y={86} color="#3949AB">বাড়ির ছাদ · রাত</Pill>
    </>
  );
};
