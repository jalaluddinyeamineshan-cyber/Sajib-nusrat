import React from 'react';
import {FLOOR, OUTLINE, fontFamily} from '../theme';
import {between, pop, trk} from '../anim';
import {STAMPS} from '../data/timeline';
import {Stage} from '../components/Stage';
import {useT} from '../components/SceneCtx';
import {Character} from '../components/Character';
import {Facade, FacadeFront, FacadeRail, LivingRoom, MGBackground, NightSky, Rooftop} from '../components/Backgrounds';
import {Pill, Stamp} from '../components/Overlays';
import {IconClock, IconCross, IconHeart, IconMoon, IconQuestion, IconRemote, IconTV} from '../components/Icons';
import {Cushion, Remote} from '../components/Props';
import {CROSS_L, CROSS_R} from './Scenes1';

/* ---------- Scene 9 : ছাদের গল্প, হাসি, চাচি রেহানা ---------- */
const Scene9a: React.FC = () => {
  const t = useT();
  const laugh = t >= 133.76;
  return (
    <Stage zoom={0.04} ox={1300} oy={500} shake={[[133.9, 135.5]]}>
      <Rooftop />
      <Character who="nusrat" x={1250} y={FLOOR} sit shawl expr={laugh ? 'laugh' : 'happy'} jitter={laugh ? 2 : 0} look={[-4, 0]} armL={CROSS_L} armR={CROSS_R} />
      <Character who="sajib" x={1030} y={FLOOR} sit expr={laugh ? 'laugh' : 'happy'} jitter={laugh ? 2 : 0} look={[4, 0]} />
    </Stage>
  );
};

const Scene9b: React.FC = () => {
  const t = useT();
  const [ry] = trk(t, [[135.54, 1200], [136.7, 914]]);
  const f = (t * 30) | 0;
  return (
    <>
      <Stage zoom={0.04} ox={900} oy={600}>
        <Facade />
        <Character who="nusrat" x={1260} y={500} scale={0.58} shawl expr="laugh" jitter={1.6} talking={false} />
        <Character who="sajib" x={1090} y={500} scale={0.58} expr="laugh" jitter={1.6} talking={false} />
        {[0, 1, 2].map((i) => (
          <path key={i} d={`M${1360 + i * 26} ${250 - i * 22} q22 ${12} 0 ${30 + ((f + i * 6) % 8)}`} fill="none" stroke="#FFE066" strokeWidth={6} strokeLinecap="round" opacity={0.85} />
        ))}
        <FacadeFront />
        <Character who="rehana" x={640} y={ry} scale={0.95} expr="neutral" headTilt={10} look={[4, -5]} talking={false} />
        <FacadeRail />
      </Stage>
      <Pill from={136.8} to={140.2} x={640} y={290} color="#7B4BA0">চাচি রেহানা</Pill>
      <Stamp from={STAMPS.never.from} to={STAMPS.never.to} x={1360} y={690} rot={4} color="#E53935">টিভির সামনে বছরেও হয়নি</Stamp>
    </>
  );
};

export const Scene9: React.FC = () => {
  const t = useT();
  return t < 135.54 ? <Scene9a /> : <Scene9b />;
};

/* ---------- Scene 10 : পরদিন রাত — রিমোট হাত বদল, ড্রয়ার, শাল ---------- */
export const Scene10: React.FC = () => {
  const t = useT();
  const sajibHold = t < 149.2;
  const [nx] = trk(t, [[144.54, 820], [152.18, 820], [153.4, 1330]]);
  const nWalk = between(t, 152.18, 153.4);
  const nFlip = t < 152.18;
  const drawer = t < 153.5 ? 0 : t < 154.1 ? trk(t, [[153.5, 0], [154.1, 1]])[0] : t < 154.5 ? 1 : trk(t, [[154.5, 1], [155.1, 0]])[0];
  const nRemote = t >= 149.2 && t < 154.2;
  const [sa, sb] = trk(t, [[146.0, 10, 40], [147.0, 25, 50], [148.2, 25, 50], [149.0, 85, -5], [150.2, 85, -5], [151.0, 6, 4]]);
  const [na, nb] = trk(t, [[148.6, 6, 4], [149.2, 85, -5], [150.4, 85, -5], [151.6, 6, 40], [153.4, 6, 40], [153.6, 10, 8]]);
  const shawlArm: [number, number] = between(t, 156.4, 157.2) ? [150, 0] : [6, 4];
  const nArmR: [number, number] = t >= 153.6 && t < 155.3 ? [10, 8] : t >= 156.4 ? shawlArm : [na, nb];
  return (
    <Stage zoom={0.04} ox={900} oy={600}>
      <LivingRoom tv="off" drawerOpen={drawer} plug={null} coil />
      <Character
        who="sajib" x={380} y={FLOOR} expr={t < 149 ? 'neutral' : 'happy'} look={[5, 0]}
        armL={t < 149.6 ? [20, 60] : [-6, -4]} armR={[sa, sb]}
        hold={(h) => (
          <>
            {t < 149.6 && <Cushion x={h.L.x + 4} y={h.L.y - 8} w={190} h={80} rot={8} fill="#FFFFFF" />}
            {sajibHold && t >= 146.0 && <Remote x={h.R.x + 6} y={h.R.y - 6} rot={80} s={1.1} />}
          </>
        )}
      />
      <Character
        who="nusrat" x={nx} y={FLOOR} flip={nFlip} walk={nWalk} crouch={t >= 153.6 && t < 155.3 ? 45 : 0}
        shawl={t >= 157.2} expr={t < 149.2 ? 'neutral' : 'happy'} look={[0, 0]}
        armR={nArmR}
        hold={(h) => (nRemote ? <Remote x={h.R.x + 4} y={h.R.y - 6} rot={nb > 40 ? 20 : 80} s={1.1} /> : null)}
      />
    </Stage>
  );
};

/* ---------- Scene 11 : আসল প্রশ্ন — মোশন গ্রাফিক্স ---------- */
const FacingCard: React.FC<{cx: number; cy: number; s: number; title: string; color: string; children: React.ReactNode}> = ({cx, cy, s, title, color, children}) => {
  if (s <= 0) return null;
  return (
    <g transform={`translate(${cx} ${cy}) scale(${s})`}>
      <rect x={-380} y={-260} width={760} height={560} rx={44} fill="#fff" stroke={OUTLINE} strokeWidth={6} />
      <rect x={-380} y={-260} width={760} height={110} rx={44} fill={color} stroke={OUTLINE} strokeWidth={6} />
      <rect x={-377} y={-200} width={754} height={50} fill={color} />
      <text x={0} y={-178} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={60} fill="#fff">{title}</text>
      {children}
    </g>
  );
};

export const Scene11: React.FC = () => {
  const t = useT();
  const sc = 1.0;
  const clockMin = trk(t, [[169.4, 0], [172.2, 60]])[0];
  return (
    <Stage zoom={0.02}>
      <MGBackground />
      {/* 1) রিমোট কার হাতে — ক্রস */}
      {between(t, 165.2, 169.1) && (
        <g transform={`translate(960 520) rotate(${Math.sin(t * 9) * 3}) scale(${pop(t, 165.2, 169.1) * 2.3})`}>
          <IconRemote />
          <IconCross />
        </g>
      )}
      {/* 2) এক ঘণ্টা */}
      {between(t, 169.2, 172.5) && (
        <g transform={`translate(960 540) scale(${pop(t, 169.2, 172.5) * 2.2})`}>
          <IconClock minute={clockMin} />
        </g>
      )}
      {between(t, 169.4, 172.5) && (
        <g transform={`translate(1500 360) scale(${pop(t, 169.4, 172.5) * 1.1})`}><IconMoon /></g>
      )}
      {/* 3) দুই কার্ড */}
      <FacingCard cx={500} cy={590} s={pop(t, 172.5, 177.0)} title="একে অপরের দিকে" color="#E91E63">
        <g transform="translate(0 0)">
          <Character who="sajib" x={-150} y={280 + 300 * sc} scale={sc} clipY={-300} talking={false} expr="happy" look={[5, 0]} />
          <Character who="nusrat" x={150} y={280 + 300 * sc} scale={sc} flip clipY={-300} talking={false} expr="happy" look={[5, 0]} />
          <g transform={`translate(0 -20) scale(${0.5 + 0.05 * Math.sin(t * 7)})`}><IconHeart /></g>
        </g>
      </FacingCard>
      <FacingCard cx={1420} cy={590} s={pop(t, 174.9, 177.0)} title="পর্দার দিকে" color="#5E6B7A">
        <g transform="translate(0 40) scale(2.1)"><IconTV /></g>
      </FacingCard>
      {between(t, 175.2, 177.0) && (
        <g transform={`translate(960 600) scale(${pop(t, 175.2, 177.0)})`}>
          <circle r={74} fill="#FFD84D" stroke={OUTLINE} strokeWidth={6} />
          <text y={22} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={62} fill={OUTLINE}>নাকি?</text>
        </g>
      )}
      {/* শিরোনাম: আসল প্রশ্ন */}
      {t >= 169.1 && (
        <g transform={`translate(960 110) scale(${pop(t, 169.1, 177.0) || 1})`}>
          <rect x={-300} y={-62} width={600} height={124} rx={62} fill="#7C4DFF" stroke={OUTLINE} strokeWidth={6} />
          <text x={40} y={26} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={76} fill="#fff">আসল প্রশ্ন</text>
          <g transform="translate(-215 0) scale(0.55)"><IconQuestion /></g>
        </g>
      )}
    </Stage>
  );
};

/* ---------- Scene 12 : শেষ কোটেশন কার্ড ---------- */
export const Scene12: React.FC = () => {
  const t = useT();
  const out = trk(t, [[180.9, 0], [181.45, 0.9]])[0];
  return (
    <Stage zoom={0.02}>
      <NightSky />
      <g transform={`translate(960 150) scale(${(0.9 + 0.08 * Math.sin(t * 6)) * (pop(t, 177.0, 182) || 1)})`}><IconHeart /></g>
      <g transform={`translate(960 560) scale(${pop(t, 177.05, 182) || 1})`}>
        <rect x={-780} y={-230} width={1560} height={520} rx={56} fill="#FFF6E5" stroke={OUTLINE} strokeWidth={7} />
        <g transform={`scale(${pop(t, 177.1, 182) || 1})`}>
          <text x={0} y={-60} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={98} fill={OUTLINE}>
            <tspan fill="#E53935">রিমোট</tspan> হারালে ক্ষতি নেই।
          </text>
        </g>
        {t >= 178.86 && (
          <g transform={`scale(${pop(t, 178.86, 182) || 1})`}>
            <text x={0} y={90} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={72} fill={OUTLINE}>কথা বলার সময় ফিরে পাওয়াই</text>
            <text x={0} y={206} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={110} fill="#E8A100">আসল জয়!</text>
          </g>
        )}
      </g>
      <rect width={1920} height={1080} fill="#000" opacity={out} />
    </Stage>
  );
};
