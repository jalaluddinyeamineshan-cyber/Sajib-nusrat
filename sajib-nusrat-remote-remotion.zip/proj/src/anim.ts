export const ease = (x: number) => x * x * (3 - 2 * x);
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));

/** Keyframe tracks: keys = [[time, v1, v2, ...], ...] (seconds). Returns eased values. */
export function trk(t: number, keys: number[][]): number[] {
  if (t <= keys[0][0]) return keys[0].slice(1);
  const last = keys[keys.length - 1];
  if (t >= last[0]) return last.slice(1);
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i];
    const b = keys[i + 1];
    if (t >= a[0] && t < b[0]) {
      const p = ease((t - a[0]) / (b[0] - a[0]));
      return a.slice(1).map((v, j) => v + (b[j + 1] - v) * p);
    }
  }
  return last.slice(1);
}

export const between = (t: number, a: number, b: number) => t >= a && t < b;

const backOut = (x: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};

/** Pop-in (overshoot) and pop-out scale for an element visible between from..to seconds. */
export function pop(t: number, from: number, to: number): number {
  if (t < from || t > to) return 0;
  const i = clamp01((t - from) / 0.28);
  const o = clamp01((to - t) / 0.2);
  return backOut(i) * ease(o);
}
