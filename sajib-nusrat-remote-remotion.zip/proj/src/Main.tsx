import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {SCENE_TIMES, TOTAL_FRAMES} from './data/timeline';
import {SceneProvider} from './components/SceneCtx';
import {Bubbles, Captions} from './components/Overlays';
import {sec} from './theme';
import {Scene1, Scene2, Scene3, Scene4} from './scenes/Scenes1';
import {Scene5, Scene6, Scene7, Scene8} from './scenes/Scenes2';
import {Scene9, Scene10, Scene11, Scene12} from './scenes/Scenes3';

const SCENES: React.FC[] = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7, Scene8, Scene9, Scene10, Scene11, Scene12];

export const Main: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    <Audio src={staticFile('voice.mp3')} volume={1} />
    {SCENES.map((Comp, i) => {
      const from = sec(SCENE_TIMES[i]);
      const end = i === SCENES.length - 1 ? TOTAL_FRAMES : sec(SCENE_TIMES[i + 1]);
      return (
        <Sequence key={i} from={from} durationInFrames={end - from}>
          <SceneProvider start={from} dur={end - from}>
            <Comp />
          </SceneProvider>
        </Sequence>
      );
    })}
    <Bubbles />
    <Captions />
  </AbsoluteFill>
);
