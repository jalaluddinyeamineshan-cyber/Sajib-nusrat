import React from 'react';
import {OUTLINE, SW} from '../theme';

const S = {stroke: OUTLINE, strokeWidth: SW + 1, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

/** All icons are centred on (0,0), roughly 200 x 200 units. Scale with a parent transform. */

export const IconBank: React.FC = () => (
  <g>
    <polygon points="-90,-30 0,-95 90,-30" fill="#F2C14E" {...S} />
    <rect x={-80} y={-30} width={160} height={14} fill="#E8B13A" {...S} />
    {[-60, -20, 20, 60].map((x) => (
      <rect key={x} x={x - 11} y={-14} width={22} height={80} fill="#FFF3D6" {...S} />
    ))}
    <rect x={-92} y={66} width={184} height={20} fill="#E8B13A" {...S} />
    <circle cx={0} cy={-52} r={13} fill="#FFF3D6" {...S} />
  </g>
);

export const IconSchool: React.FC = () => (
  <g>
    <rect x={-85} y={-30} width={170} height={110} rx={8} fill="#E26D5A" {...S} />
    <polygon points="-95,-30 0,-85 95,-30" fill="#B8453A" {...S} />
    <rect x={-20} y={20} width={40} height={60} fill="#FFF3D6" {...S} />
    {[-60, 45].map((x) => (
      <rect key={x} x={x} y={-5} width={28} height={30} fill="#9ED8F0" {...S} />
    ))}
    <line x1={0} y1={-85} x2={0} y2={-120} {...S} />
    <polygon points="0,-120 36,-108 0,-96" fill="#4CAF50" {...S} />
  </g>
);

export const IconSun: React.FC = () => (
  <g>
    {Array.from({length: 8}).map((_, i) => (
      <line key={i} x1={0} y1={-62} x2={0} y2={-88} transform={`rotate(${i * 45})`} stroke="#F5A623" strokeWidth={9} strokeLinecap="round" />
    ))}
    <circle r={46} fill="#FFD84D" {...S} />
  </g>
);

export const IconMoon: React.FC = () => (
  <g>
    <path d="M30 -70 A75 75 0 1 0 70 30 A58 58 0 1 1 30 -70 Z" fill="#FFE9A6" {...S} />
  </g>
);

export const IconPlate: React.FC = () => (
  <g>
    <ellipse cx={0} cy={30} rx={90} ry={26} fill="#FFFFFF" {...S} />
    <ellipse cx={0} cy={26} rx={62} ry={15} fill="#F3F3F3" stroke="#CFCFCF" strokeWidth={2} />
    <path d="M-48 22 Q-40 -34 0 -38 Q40 -34 48 22 Z" fill="#FFFDF3" {...S} />
    <ellipse cx={34} cy={22} rx={26} ry={10} fill="#E8892B" {...S} />
    <path d="M-20 -60 q-10 -14 0 -26 M6 -62 q-10 -14 0 -26 M30 -56 q-10 -14 0 -26" fill="none" stroke="#B9B9B9" strokeWidth={5} strokeLinecap="round" />
  </g>
);

export const IconRemote: React.FC = () => (
  <g>
    <rect x={-34} y={-90} width={68} height={180} rx={22} fill="#3A3F47" {...S} />
    <circle cx={0} cy={-58} r={13} fill="#E53935" {...S} />
    {[0, 1, 2].map((r) =>
      [-14, 14].map((x) => <circle key={`${r}${x}`} cx={x} cy={-18 + r * 30} r={8} fill="#CFD8DC" stroke={OUTLINE} strokeWidth={2} />)
    )}
    <rect x={-16} y={72} width={32} height={8} rx={4} fill="#CFD8DC" />
  </g>
);

export const IconTV: React.FC<{screen?: string}> = ({screen = '#2E9E5B'}) => (
  <g>
    <rect x={-100} y={-70} width={200} height={130} rx={16} fill="#2B2B2B" {...S} />
    <rect x={-86} y={-56} width={172} height={102} rx={8} fill={screen} />
    <ellipse cx={0} cy={0} rx={60} ry={30} fill="none" stroke="#fff" strokeWidth={3} opacity={0.7} />
    <rect x={-8} y={60} width={16} height={18} fill="#2B2B2B" />
    <rect x={-44} y={76} width={88} height={10} rx={5} fill="#2B2B2B" />
  </g>
);

export const IconClock: React.FC<{minute?: number}> = ({minute = 0}) => (
  <g>
    <circle r={84} fill="#FFFFFF" {...S} />
    {Array.from({length: 12}).map((_, i) => (
      <line key={i} x1={0} y1={-70} x2={0} y2={-60} transform={`rotate(${i * 30})`} stroke={OUTLINE} strokeWidth={4} />
    ))}
    <line x1={0} y1={0} x2={0} y2={-52} stroke={OUTLINE} strokeWidth={8} strokeLinecap="round" transform={`rotate(${(minute / 60) * 30 + 270 - 270})`} />
    <line x1={0} y1={0} x2={0} y2={-68} stroke="#E53935" strokeWidth={5} strokeLinecap="round" transform={`rotate(${(minute / 60) * 360})`} />
    <circle r={7} fill={OUTLINE} />
  </g>
);

export const IconNotebook: React.FC = () => (
  <g>
    <rect x={-70} y={-85} width={140} height={170} rx={10} fill="#4C8DF6" {...S} />
    <rect x={-56} y={-70} width={112} height={140} rx={4} fill="#FFFFFF" />
    {[-44, -24, 52].map((y) => (
      <line key={y} x1={-42} y1={y} x2={42} y2={y} stroke="#C9D6EA" strokeWidth={4} />
    ))}
    <text x={0} y={34} textAnchor="middle" fontSize={96} fontWeight={700} fill="#E53935" fontFamily="sans-serif">?</text>
  </g>
);

export const IconGlassesFace: React.FC = () => (
  <g>
    <circle cx={0} cy={10} r={72} fill="#D9A576" {...S} />
    <path d="M-72 -4 Q0 -86 72 -4 Q40 -50 0 -50 Q-40 -50 -72 -4Z" fill="#8E8E8E" {...S} />
    <g fill="rgba(158,216,240,0.55)" stroke="#222" strokeWidth={5}>
      <circle cx={-28} cy={-44} r={24} />
      <circle cx={28} cy={-44} r={24} />
    </g>
    <line x1={-4} y1={-44} x2={4} y2={-44} stroke="#222" strokeWidth={5} />
    <circle cx={-26} cy={12} r={7} fill="#222" />
    <circle cx={26} cy={12} r={7} fill="#222" />
    <path d="M-12 52 Q0 62 12 52" fill="none" stroke="#222" strokeWidth={5} strokeLinecap="round" />
    <path d="M-70 -92 l-18 -14 M0 -104 l0 -22 M70 -92 l18 -14" stroke="#F5A623" strokeWidth={6} strokeLinecap="round" />
  </g>
);

export const IconHorn: React.FC = () => (
  <g>
    <path d="M-50 -20 L10 -20 L70 -60 L70 60 L10 20 L-50 20 Z" fill="#F2C14E" {...S} />
    <circle cx={-62} cy={0} r={18} fill="#333" {...S} />
    <path d="M90 -34 Q112 0 90 34 M108 -58 Q146 0 108 58" fill="none" stroke={OUTLINE} strokeWidth={7} strokeLinecap="round" />
  </g>
);

export const IconFan: React.FC<{angle: number}> = ({angle}) => (
  <g transform={`rotate(${angle})`}>
    {[0, 120, 240].map((a) => (
      <rect key={a} x={-18} y={-92} width={36} height={84} rx={18} fill="#9AB8C8" {...S} transform={`rotate(${a})`} />
    ))}
    <circle r={20} fill="#556B77" {...S} />
  </g>
);

export const IconCross: React.FC = () => (
  <g>
    <circle r={84} fill="none" stroke="#E53935" strokeWidth={14} />
    <line x1={-60} y1={-60} x2={60} y2={60} stroke="#E53935" strokeWidth={14} strokeLinecap="round" />
  </g>
);

export const IconHeart: React.FC = () => (
  <path d="M0 60 C-110 -10 -60 -90 0 -34 C60 -90 110 -10 0 60 Z" fill="#F0516D" {...S} />
);

export const IconStar5: React.FC<{fill?: string}> = ({fill = '#FFE066'}) => (
  <polygon points="0,-80 23,-25 82,-25 34,10 52,66 0,32 -52,66 -34,10 -82,-25 -23,-25" fill={fill} {...S} />
);

export const IconQuestion: React.FC = () => (
  <g>
    <circle r={80} fill="#7C4DFF" {...S} />
    <text x={0} y={44} textAnchor="middle" fontSize={120} fontWeight={700} fill="#fff" fontFamily="sans-serif">?</text>
  </g>
);

export const IconEyes: React.FC = () => (
  <g>
    {[-44, 44].map((x) => (
      <g key={x}>
        <ellipse cx={x} cy={0} rx={38} ry={46} fill="#fff" {...S} />
        <circle cx={x + 10} cy={4} r={18} fill={OUTLINE} />
        <circle cx={x + 16} cy={-2} r={6} fill="#fff" />
      </g>
    ))}
  </g>
);
