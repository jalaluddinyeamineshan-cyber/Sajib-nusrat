import React from 'react';
import {OUTLINE, SW} from '../theme';

const S = {stroke: OUTLINE, strokeWidth: SW + 0.5, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

/** TV remote, centred on its middle. */
export const Remote: React.FC<{x: number; y: number; rot?: number; s?: number; glow?: boolean}> = ({x, y, rot = 0, s = 1, glow}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
    {glow && <ellipse rx={46} ry={78} fill="#FFE066" opacity={0.55} />}
    <rect x={-15} y={-42} width={30} height={84} rx={10} fill="#3A3F47" {...S} />
    <circle cx={0} cy={-28} r={6} fill="#E53935" stroke={OUTLINE} strokeWidth={1.5} />
    {[0, 1, 2].map((r) =>
      [-6, 6].map((xx) => <circle key={`${r}${xx}`} cx={xx} cy={-8 + r * 14} r={3.4} fill="#CFD8DC" />)
    )}
  </g>
);

export const Plate: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx={0} cy={0} rx={68} ry={17} fill="#fff" {...S} />
    <ellipse cx={0} cy={-2} rx={46} ry={10} fill="#F2F2F2" stroke="#CFCFCF" strokeWidth={1.5} />
    <path d="M-34 -4 Q-28 -30 0 -32 Q28 -30 34 -4 Z" fill="#FFFDF3" {...S} />
    <ellipse cx={26} cy={-4} rx={18} ry={7} fill="#E8892B" stroke={OUTLINE} strokeWidth={2} />
  </g>
);

export const Spoon: React.FC<{x: number; y: number; rot?: number}> = ({x, y, rot = 0}) => (
  <g transform={`translate(${x},${y}) rotate(${rot})`}>
    <rect x={-3} y={-8} width={6} height={52} rx={3} fill="#C9CED3" {...S} />
    <ellipse cx={0} cy={-14} rx={11} ry={15} fill="#C9CED3" {...S} />
    <ellipse cx={0} cy={-16} rx={7} ry={9} fill="#FFFDF3" />
  </g>
);

export const Cushion: React.FC<{x: number; y: number; rot?: number; sx?: number; w?: number; h?: number; fill?: string}> = ({x, y, rot = 0, sx = 1, w = 230, h = 90, fill = '#F5C6A5'}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${sx},1)`}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={34} fill={fill} {...S} />
    <path d={`M${-w / 2 + 20} 0 Q0 ${h / 5} ${w / 2 - 20} 0`} fill="none" stroke="#D9A07C" strokeWidth={3} />
  </g>
);

export const Plug: React.FC<{x: number; y: number; rot?: number}> = ({x, y, rot = 0}) => (
  <g transform={`translate(${x},${y}) rotate(${rot})`}>
    <rect x={-14} y={-10} width={28} height={24} rx={6} fill="#EDEDED" {...S} />
    <rect x={-8} y={-26} width={5} height={16} fill="#B0B0B0" stroke={OUTLINE} strokeWidth={1.5} />
    <rect x={3} y={-26} width={5} height={16} fill="#B0B0B0" stroke={OUTLINE} strokeWidth={1.5} />
  </g>
);

export const Towel: React.FC = () => (
  <g>
    <path d="M18 -430 L96 -388 L84 -340 L6 -380 Z" fill="#F7F7F7" {...S} />
    <path d="M24 -418 L90 -380 M20 -400 L82 -364" stroke="#4DB6E6" strokeWidth={5} />
  </g>
);

export const Shawl: React.FC<{w: number}> = ({w}) => (
  <g>
    <path d={`M${-w - 22} -420 Q0 -358 ${w + 22} -420 L${w + 40} -250 Q${w - 20} -170 ${-w + 38} -230 L${-w - 40} -258 Z`} fill="#8E1B2B" {...S} />
    <path d={`M${-w + 20} -372 Q${w * 0.1} -318 ${w - 6} -262`} fill="none" stroke="#B02A3E" strokeWidth={5} strokeLinecap="round" />
  </g>
);
