import React, {createContext, useContext} from 'react';
import {useCurrentFrame} from 'remotion';
import {FPS} from '../theme';
import {DIALOGUES} from '../data/timeline';

type Ctx = {start: number; dur: number};
const SceneCtx = createContext<Ctx>({start: 0, dur: 1});

export const SceneProvider: React.FC<Ctx & {children: React.ReactNode}> = ({start, dur, children}) => (
  <SceneCtx.Provider value={{start, dur}}>{children}</SceneCtx.Provider>
);

export const useScene = () => useContext(SceneCtx);

/** Absolute time in seconds on the whole video timeline. */
export const useT = () => {
  const f = useCurrentFrame();
  const {start} = useScene();
  return (f + start) / FPS;
};

export const useTalking = (who: string) => {
  const t = useT();
  return DIALOGUES.some((d) => d.who === who && d.kind === 'speech' && t >= d.from && t < d.to);
};
