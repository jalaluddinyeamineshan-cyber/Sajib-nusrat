import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {FPS, OUTLINE, fontFamily} from '../theme';
import {pop, ease} from '../anim';
import {CAPTIONS} from '../data/captions';
import {DIALOGUES, hideCaption} from '../data/timeline';
import {IconNotebook, IconGlassesFace} from './Icons';
import {useT} from './SceneCtx';

const TINT = {sajib: '#E6F0FF', nusrat: '#E8F8EC', rehana: '#F3E8FA'};

/** All speech bubbles (absolute timeline). Text comes from the script. */
export const Bubbles: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <svg viewBox="0 0 1920 1080" width="100%" height="100%">
        {DIALOGUES.map((d) => {
          const s = pop(t, d.from, d.to);
          if (s <= 0) return null;
          const bx = Math.max(d.x + 60, Math.min(d.x + d.w - 60, d.tx));
          const fill = TINT[d.who];
          return (
            <g key={d.id} transform={`translate(${d.tx} ${d.ty}) scale(${s}) translate(${-d.tx} ${-d.ty})`}>
              <polygon points={`${bx - 26},${d.y + d.h - 4} ${bx + 26},${d.y + d.h - 4} ${d.tx},${d.ty}`} fill={fill} stroke={OUTLINE} strokeWidth={4.5} strokeLinejoin="round" />
              <rect x={d.x} y={d.y} width={d.w} height={d.h} rx={38} fill={fill} stroke={OUTLINE} strokeWidth={4.5} />
              <rect x={bx - 22} y={d.y + d.h - 8} width={44} height={10} fill={fill} />
              {d.lines &&
                d.lines.map((ln, i) => (
                  <text
                    key={i}
                    x={d.x + d.w / 2}
                    y={d.y + d.h / 2 + (i - (d.lines!.length - 1) / 2) * 62 + 16}
                    textAnchor="middle"
                    fontFamily={fontFamily}
                    fontWeight={700}
                    fontSize={46}
                    fill={OUTLINE}
                  >
                    {ln}
                  </text>
                ))}
              {d.icon && (
                <g transform={`translate(${d.x + d.w / 2} ${d.y + d.h / 2}) scale(0.95)`}>
                  {d.icon === 'notebook' ? <IconNotebook /> : <IconGlassesFace />}
                </g>
              )}
            </g>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};

const KEYWORDS = ['রিমোট', 'টিভি', 'তারা', 'ছাদ', 'গোসল', 'বালিশ', 'প্লাগ', 'plug', 'socket', 'drawer', 'শাল', 'ক্রিকেট', 'ভাত', 'চাচি', 'রেহানা', 'হাসল', 'ব্যাংক', 'স্কুল', 'cushion', 'নাটক'];

/** Floating bottom caption (only when no callout/card is visible). */
export const Captions: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const cap = CAPTIONS.find((c) => t >= c.from && t < c.to);
  if (!cap || hideCaption(t)) return null;
  const p = ease(Math.min(1, (t - cap.from) / 0.2));
  const words = cap.text.split(' ');
  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', pointerEvents: 'none'}}>
      <div
        style={{
          marginBottom: 64 - (1 - p) * 24,
          opacity: p,
          fontFamily,
          fontWeight: 700,
          fontSize: 62,
          color: '#fff',
          textAlign: 'center',
          whiteSpace: 'nowrap',
          WebkitTextStroke: '9px #1b1b1b',
          paintOrder: 'stroke fill',
          letterSpacing: 0.5,
        }}
      >
        {words.map((w, i) => {
          const hi = KEYWORDS.some((k) => w.toLowerCase().includes(k.toLowerCase()));
          return (
            <span key={i} style={{color: hi ? '#FFD84D' : '#fff'}}>
              {w}
              {i < words.length - 1 ? ' ' : ''}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

/** Colourful name / location pill that pops in over the scene. */
export const Pill: React.FC<{from: number; to: number; x: number; y: number; color: string; children: React.ReactNode; size?: number; fg?: string}> = ({from, to, x, y, color, children, size = 44, fg = '#fff'}) => {
  const t = useT();
  const s = pop(t, from, to);
  if (s <= 0) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) scale(${s})`,
        background: color,
        color: fg,
        border: '5px solid #222',
        borderRadius: 999,
        padding: '8px 34px',
        fontFamily,
        fontWeight: 700,
        fontSize: size,
        whiteSpace: 'nowrap',
        boxShadow: '0 6px 0 rgba(0,0,0,0.25)',
      }}
    >
      {children}
    </div>
  );
};

/** Bold stamp-style card. */
export const Stamp: React.FC<{from: number; to: number; x: number; y: number; rot?: number; color: string; children: React.ReactNode; size?: number}> = ({from, to, x, y, rot = -5, color, children, size = 64}) => {
  const t = useT();
  const s = pop(t, from, to);
  if (s <= 0) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${s})`,
        background: 'rgba(255,255,255,0.96)',
        color,
        border: `10px solid ${color}`,
        borderRadius: 26,
        padding: '10px 36px',
        fontFamily,
        fontWeight: 700,
        fontSize: size,
        whiteSpace: 'nowrap',
        textAlign: 'center',
        boxShadow: '0 8px 0 rgba(0,0,0,0.25)',
      }}
    >
      {children}
    </div>
  );
};
