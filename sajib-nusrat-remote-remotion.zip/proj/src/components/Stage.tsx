import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {useScene} from './SceneCtx';
import {FPS} from '../theme';

/** Full-screen (edge-to-edge) SVG stage with slow camera push, fade-in and optional screen shake. */
export const Stage: React.FC<{zoom?: number; ox?: number; oy?: number; shake?: [number, number][]; children: React.ReactNode}> = ({zoom = 0.05, ox = 960, oy = 540, shake = [], children}) => {
  const f = useCurrentFrame();
  const {start, dur} = useScene();
  const t = (f + start) / FPS;
  const z = 1.025 + zoom * (f / dur);
  const shaking = shake.some(([a, b]) => t >= a && t < b);
  const dx = shaking ? Math.sin(f * 2.3) * 8 : 0;
  const dy = shaking ? Math.cos(f * 3.1) * 6 : 0;
  const fade = interpolate(f, [0, 5], [0.35, 1], {extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{opacity: fade, backgroundColor: '#000'}}>
      <div style={{position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', transform: `translate(${dx}px,${dy}px) scale(${z})`, transformOrigin: `${ox}px ${oy}px`}}>
        <svg viewBox="0 0 1920 1080" width="100%" height="100%" preserveAspectRatio="xMidYMid slice" style={{display: 'block'}}>
          {children}
        </svg>
      </div>
    </AbsoluteFill>
  );
};
