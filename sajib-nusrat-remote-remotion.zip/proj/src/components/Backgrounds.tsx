import React from 'react';
import {useCurrentFrame} from 'remotion';
import {OUTLINE, SW} from '../theme';
import {Plug} from './Props';
import {IconFan} from './Icons';
import type {Pt} from './Character';

const st = {stroke: OUTLINE, strokeWidth: SW + 0.5, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

// deterministic pseudo-random stars
const STARS = Array.from({length: 70}).map((_, i) => ({
  x: (i * 937) % 1920,
  y: ((i * 421) % 640) + 20,
  r: 1.5 + ((i * 7) % 4),
  p: i * 0.9,
}));

export const NightSky: React.FC<{h?: number}> = ({h = 1080}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0A0E2E" />
          <stop offset="1" stopColor="#34408A" />
        </linearGradient>
      </defs>
      <rect width={1920} height={h} fill="url(#sky)" />
      {STARS.map((s, i) => (
        <circle key={i} cx={s.x} cy={s.y} r={s.r} fill="#FFF8D6" opacity={0.55 + 0.45 * Math.sin(f / 10 + s.p)} />
      ))}
      <circle cx={250} cy={190} r={62} fill="#FFF3C4" />
      <circle cx={276} cy={176} r={56} fill="#0F1540" opacity={0.0} />
    </g>
  );
};

export const TvScreen: React.FC<{kind: 'cricket' | 'drama' | 'off'; x: number; y: number; w: number; h: number}> = ({kind, x, y, w, h}) => {
  const f = useCurrentFrame();
  const fl = 0.93 + 0.07 * Math.sin(f / 3);
  if (kind === 'off') {
    return (
      <g>
        <rect x={x} y={y} width={w} height={h} rx={8} fill="#101010" />
        <polygon points={`${x + 20},${y + h} ${x + w * 0.45},${y} ${x + w * 0.6},${y} ${x + 40 + w * 0.15},${y + h}`} fill="#fff" opacity={0.07} />
      </g>
    );
  }
  if (kind === 'cricket') {
    return (
      <g opacity={fl}>
        <rect x={x} y={y} width={w} height={h} rx={8} fill="#3E9E5A" />
        <ellipse cx={x + w / 2} cy={y + h / 2 - 10} rx={w * 0.42} ry={h * 0.36} fill="#52B26C" stroke="#fff" strokeWidth={3} />
        <rect x={x + w / 2 - 14} y={y + h / 2 - 54} width={28} height={84} fill="#D9B77E" />
        {[[-60, -30], [60, -10], [-30, 40], [90, 40], [0, -62]].map(([dx, dy], i) => (
          <circle key={i} cx={x + w / 2 + dx} cy={y + h / 2 + dy} r={7} fill="#fff" stroke={OUTLINE} strokeWidth={2} />
        ))}
        <rect x={x} y={y + h - 40} width={w} height={40} fill="#14213D" />
        <circle cx={x + 24} cy={y + h - 20} r={7} fill="#E53935" />
        {[0, 1, 2, 3, 4, 5].map((i) => <circle key={i} cx={x + 90 + i * 28} cy={y + h - 20} r={8} fill={i < 5 ? '#F5F5F5' : '#FFD84D'} />)}
      </g>
    );
  }
  return (
    <g opacity={fl}>
      <defs>
        <linearGradient id="drama" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#6B3FA0" />
          <stop offset="1" stopColor="#E86AA0" />
        </linearGradient>
      </defs>
      <rect x={x} y={y} width={w} height={h} rx={8} fill="url(#drama)" />
      {[-70, 70].map((dx) => (
        <g key={dx}>
          <circle cx={x + w / 2 + dx} cy={y + h / 2 - 30} r={42} fill="#F7DCC6" stroke={OUTLINE} strokeWidth={3} />
          <rect x={x + w / 2 + dx - 38} y={y + h / 2 + 12} width={76} height={80} rx={28} fill={dx < 0 ? '#2E5CA8' : '#E26D5A'} stroke={OUTLINE} strokeWidth={3} />
        </g>
      ))}
      <path d={`M${x + w / 2} ${y + h / 2 - 50} c-18 -22 -42 6 0 30 c42 -24 18 -52 0 -30z`} fill="#FF4D6D" />
    </g>
  );
};

export type LivingProps = {
  tv: 'cricket' | 'drama' | 'off';
  dim?: number;
  table?: boolean;
  cushionOut?: boolean;
  plug?: Pt | null; // plug end of the cable (null: cable hidden)
  coil?: boolean;
  drawerOpen?: number;
  fanSpin?: boolean;
  glow?: boolean;
};

export const SOCKET: Pt = {x: 1866, y: 580};

export const LivingRoom: React.FC<LivingProps> = ({tv, dim = 0, table, cushionOut, plug = SOCKET, coil, drawerOpen = 0, fanSpin = true, glow}) => {
  const f = useCurrentFrame();
  const P = plug;
  return (
    <g>
      {/* wall + floor */}
      <rect width={1920} height={800} fill="#F3DDBD" />
      <rect y={690} width={1920} height={110} fill="#E6CCA2" />
      <rect y={796} width={1920} height={284} fill="#B88A5B" />
      {[880, 980].map((y) => <line key={y} x1={0} y1={y} x2={1920} y2={y} stroke="#A57A4E" strokeWidth={4} />)}
      <rect y={790} width={1920} height={14} fill="#8E6642" />
      <ellipse cx={960} cy={965} rx={620} ry={64} fill="#C96F5A" opacity={0.55} />
      {/* ceiling fan */}
      <rect x={990} y={0} width={20} height={34} fill="#555" />
      <g transform="translate(1000 60)"><IconFan angle={fanSpin ? f * 12 : 0} /></g>
      {/* window */}
      <rect x={90} y={110} width={320} height={360} fill="#1F3566" {...st} />
      <circle cx={330} cy={190} r={26} fill="#FFF3C4" />
      {[[160, 300], [220, 180], [300, 380], [140, 410], [360, 270]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={3.5} fill="#FFF8D6" />)}
      <line x1={250} y1={110} x2={250} y2={470} {...st} />
      <line x1={90} y1={290} x2={410} y2={290} {...st} />
      <path d="M60 100 L150 100 L130 500 L60 500 Z" fill="#C96F5A" {...st} />
      <path d="M440 100 L350 100 L370 500 L440 500 Z" fill="#C96F5A" {...st} />
      {/* picture */}
      <rect x={480} y={150} width={230} height={170} fill="#8B5A2B" {...st} />
      <rect x={494} y={164} width={202} height={142} fill="#9ED3C2" />
      <path d="M494 306 L560 220 L610 270 L650 220 L696 306 Z" fill="#6BAE8F" />
      <circle cx={655} cy={196} r={18} fill="#FFD84D" />
      {/* clock */}
      <g transform="translate(860 200)">
        <circle r={74} fill="#fff" {...st} />
        {Array.from({length: 12}).map((_, i) => <line key={i} x1={0} y1={-62} x2={0} y2={-52} transform={`rotate(${i * 30})`} stroke={OUTLINE} strokeWidth={4} />)}
        <line x1={0} y1={0} x2={-42} y2={0} stroke={OUTLINE} strokeWidth={8} strokeLinecap="round" />
        <line x1={0} y1={0} x2={0} y2={-58} stroke={OUTLINE} strokeWidth={5} strokeLinecap="round" />
        <circle r={7} fill={OUTLINE} />
      </g>
      {/* sofa */}
      <rect x={140} y={540} width={720} height={300} rx={60} fill="#3F7F8F" {...st} />
      <rect x={110} y={690} width={110} height={190} rx={45} fill="#357282" {...st} />
      <rect x={780} y={690} width={110} height={190} rx={45} fill="#357282" {...st} />
      <rect x={200} y={876} width={600} height={24} rx={8} fill="#2D5A66" {...st} />
      <rect x={200} y={796} width={310} height={84} rx={28} fill="#4E9AAB" {...st} />
      {cushionOut ? <rect x={510} y={850} width={290} height={30} fill="#2D5A66" /> : <rect x={500} y={796} width={300} height={84} rx={28} fill="#4E9AAB" {...st} />}
      {/* TV stand + TV */}
      <rect x={1240} y={690} width={620} height={210} rx={14} fill="#7A4B2A" {...st} />
      <rect x={1262} y={714} width={280} height={80} rx={8} fill="#8E5A34" {...st} />
      {drawerOpen > 0 && <rect x={1272} y={714} width={260} height={30 * drawerOpen} fill="#2A1A10" />}
      <rect x={1262} y={714 + 30 * drawerOpen} width={280} height={80} rx={8} fill="#9C6538" {...st} />
      <rect x={1380} y={742 + 30 * drawerOpen} width={44} height={10} rx={5} fill="#E8C27A" {...st} />
      <rect x={1566} y={714} width={274} height={80} rx={8} fill="#8E5A34" {...st} />
      <rect x={1690} y={744} width={44} height={10} rx={5} fill="#E8C27A" {...st} />
      <rect x={1290} y={350} width={520} height={320} rx={20} fill="#2B2B2B" {...st} />
      <TvScreen kind={tv} x={1312} y={372} w={476} h={276} />
      <rect x={1520} y={668} width={60} height={22} fill="#2B2B2B" />
      {glow && tv !== 'off' && <rect x={1290} y={350} width={520} height={320} rx={20} fill="none" stroke="#FFE066" strokeWidth={8} opacity={0.5 + 0.5 * Math.sin(f / 4)} />}
      {/* socket + cable */}
      <rect x={SOCKET.x - 26} y={SOCKET.y - 38} width={52} height={76} rx={8} fill="#F4F4F4" {...st} />
      <circle cx={SOCKET.x - 6} cy={SOCKET.y - 12} r={4} fill={OUTLINE} />
      <circle cx={SOCKET.x - 6} cy={SOCKET.y + 12} r={4} fill={OUTLINE} />
      {P && !coil && (
        <>
          <path d={`M1800 640 Q${(1800 + P.x) / 2} ${Math.max(P.y, 640) + 110} ${P.x} ${P.y}`} fill="none" stroke="#2B2B2B" strokeWidth={9} strokeLinecap="round" />
          <Plug x={P.x - 10} y={P.y} rot={90} />
        </>
      )}
      {coil && (
        <g fill="none" stroke="#2B2B2B" strokeWidth={9}>
          <ellipse cx={1550} cy={338} rx={62} ry={14} />
          <ellipse cx={1550} cy={330} rx={54} ry={12} />
          <ellipse cx={1550} cy={322} rx={46} ry={10} />
        </g>
      )}
      {table && (
        <g>
          <ellipse cx={1170} cy={906} rx={190} ry={12} fill="#000" opacity={0.15} />
          <rect x={1000} y={806} width={340} height={26} rx={10} fill="#8B5A2B" {...st} />
          <rect x={1022} y={832} width={18} height={68} fill="#6F4522" {...st} />
          <rect x={1300} y={832} width={18} height={68} fill="#6F4522" {...st} />
        </g>
      )}
      {dim > 0 && <rect width={1920} height={1080} fill="#0B1030" opacity={dim} />}
    </g>
  );
};

export const Pillow: React.FC<{x: number; y: number; bump?: number; rot?: number}> = ({x, y, bump = 0, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`}>
    <rect x={-130} y={-55} width={260} height={110} rx={52} fill="#FFFFFF" {...st} />
    {bump > 0 && <ellipse cx={-40} cy={-58 - 14 * bump} rx={52} ry={22 * bump} fill="#FFFFFF" {...st} />}
    {bump > 0 && <rect x={-96} y={-52} width={112} height={30} fill="#fff" />}
    <path d="M-100 -20 Q0 -4 100 -20" fill="none" stroke="#D5D9DD" strokeWidth={3} />
  </g>
);

export const Bedroom: React.FC<{doorOpen?: number; bump?: number; dim?: number}> = ({doorOpen = 0, bump = 0, dim = 0}) => (
  <g>
    <rect width={1920} height={800} fill="#CBE3E9" />
    <rect y={690} width={1920} height={110} fill="#B6D2DA" />
    <rect y={796} width={1920} height={284} fill="#A87F58" />
    <rect y={790} width={1920} height={14} fill="#7C5A3A" />
    <ellipse cx={1160} cy={950} rx={560} ry={56} fill="#E59B4F" opacity={0.35} />
    {/* bathroom door */}
    <rect x={110} y={220} width={320} height={680} fill="#7A5A3C" {...st} />
    <rect x={126} y={236} width={288} height={664} fill="#EAF6FB" />
    {doorOpen > 0 && <rect x={126} y={236} width={288} height={664} fill="#BFE3F2" />}
    {doorOpen > 0 && <circle cx={270} cy={330} r={22} fill="#9ED8F0" stroke={OUTLINE} strokeWidth={3} />}
    <g transform={`translate(126 0) scale(${1 - 0.86 * doorOpen} 1)`}>
      <rect x={0} y={236} width={288} height={664} fill="#C9A06A" {...st} />
      <rect x={30} y={270} width={228} height={260} rx={10} fill="#D9B27C" {...st} />
      <rect x={30} y={560} width={228} height={280} rx={10} fill="#D9B27C" {...st} />
      <circle cx={250} cy={560} r={14} fill="#E8C27A" {...st} />
    </g>
    {/* frame art + lamp */}
    <rect x={520} y={170} width={170} height={130} fill="#8B5A2B" {...st} />
    <rect x={534} y={184} width={142} height={102} fill="#F4C7A1" />
    <circle cx={605} cy={235} r={28} fill="#E26D5A" />
    <rect x={1700} y={540} width={60} height={250} fill="#6F4522" {...st} />
    <path d="M1690 540 L1770 540 L1750 470 L1710 470 Z" fill="#FFD84D" {...st} />
    {/* bed */}
    <rect x={730} y={300} width={860} height={430} rx={40} fill="#7A4B2A" {...st} />
    <rect x={700} y={640} width={920} height={220} rx={30} fill="#F6F0E4" {...st} />
    <rect x={700} y={716} width={920} height={144} rx={20} fill="#E59B4F" {...st} />
    <path d="M740 740 L1580 740 M740 790 L1580 790" stroke="#CF8337" strokeWidth={4} />
    <rect x={720} y={858} width={26} height={44} fill="#5A3519" {...st} />
    <rect x={1576} y={858} width={26} height={44} fill="#5A3519" {...st} />
    <Pillow x={890} y={600} bump={bump} />
    <Pillow x={1300} y={600} />
    {dim > 0 && <rect width={1920} height={1080} fill="#0B1030" opacity={dim} />}
  </g>
);

export const Rooftop: React.FC = () => {
  return (
    <g>
      <NightSky h={800} />
      {/* skyline */}
      {Array.from({length: 14}).map((_, i) => {
        const w = 110 + ((i * 37) % 70);
        const hh = 120 + ((i * 53) % 150);
        return (
          <g key={i}>
            <rect x={i * 140 - 20} y={760 - hh} width={w} height={hh + 40} fill="#10163A" />
            {Array.from({length: 6}).map((__, j) => (
              <rect key={j} x={i * 140 - 4 + (j % 3) * 34} y={780 - hh + Math.floor(j / 3) * 40} width={14} height={18} fill={(i + j) % 3 === 0 ? '#FFD84D' : '#2A3260'} />
            ))}
          </g>
        );
      })}
      {/* roof floor + parapet */}
      <rect y={780} width={1920} height={300} fill="#8E8E96" />
      <rect y={740} width={1920} height={50} fill="#6F6F78" {...st} />
      {[0, 1, 2, 3, 4, 5].map((i) => <line key={i} x1={i * 340} y1={800} x2={i * 340 - 120} y2={1080} stroke="#7A7A84" strokeWidth={3} />)}
      {/* tank platform */}
      <rect x={900} y={790} width={1020} height={110} rx={6} fill="#A6A6B0" {...st} />
      {/* water tank */}
      <ellipse cx={1530} cy={790} rx={150} ry={26} fill="#1E5A94" {...st} />
      <rect x={1380} y={430} width={300} height={360} fill="#2C6FB5" {...st} />
      <ellipse cx={1530} cy={430} rx={150} ry={32} fill="#4C93D6" {...st} />
      <line x1={1380} y1={560} x2={1680} y2={560} stroke="#1E5A94" strokeWidth={5} />
      <line x1={1380} y1={680} x2={1680} y2={680} stroke="#1E5A94" strokeWidth={5} />
      <ellipse cx={1530} cy={420} rx={30} ry={10} fill="#245F9C" {...st} />
      <rect x={1676} y={700} width={46} height={14} fill="#888" {...st} />
    </g>
  );
};

export const Balcony: React.FC<{open: number}> = ({open}) => (
  <g>
    <NightSky h={900} />
    <rect y={900} width={1920} height={180} fill="#6D6D75" />
    {/* wall with door panels sliding open */}
    <rect x={0} y={0} width={960 * (1 - open)} height={900} fill="#D9C3A0" {...st} />
    <rect x={960 + 960 * open} y={0} width={960} height={900} fill="#D9C3A0" {...st} />
    <rect x={960 * (1 - open) - 30} y={0} width={30} height={900} fill="#8B6B4A" {...st} />
    <rect x={960 + 960 * open} y={0} width={30} height={900} fill="#8B6B4A" {...st} />
  </g>
);

export const BalconyRail: React.FC = () => (
  <g>
    <rect y={800} width={1920} height={26} fill="#3E3E46" {...st} />
    {Array.from({length: 32}).map((_, i) => <rect key={i} x={i * 62 + 14} y={826} width={12} height={110} fill="#3E3E46" />)}
    <rect y={936} width={1920} height={20} fill="#3E3E46" {...st} />
  </g>
);

export const Facade: React.FC = () => (
  <g>
    <NightSky h={420} />
  </g>
);

export const FacadeFront: React.FC = () => (
  <g>
    <rect y={300} width={1920} height={780} fill="#D8B48A" />
    <rect y={290} width={1920} height={40} fill="#B28E66" {...st} />
    <rect y={560} width={1920} height={18} fill="#B28E66" {...st} />
    {[1100, 1380, 1660].map((x) => (
      <g key={x}>
        <rect x={x} y={380} width={150} height={140} fill="#2A2F55" {...st} />
        <rect x={x + 8} y={388} width={64} height={124} fill="#FFD36B" />
        <line x1={x + 75} y1={380} x2={x + 75} y2={520} {...st} />
      </g>
    ))}
    {[1100, 1660].map((x) => (
      <g key={'b' + x}>
        <rect x={x} y={640} width={150} height={150} fill="#2A2F55" {...st} />
        <rect x={x + 8} y={648} width={64} height={134} fill="#FFD36B" opacity={0.9} />
      </g>
    ))}
    {/* ground balcony */}
    <rect x={300} y={620} width={720} height={250} fill="#3B2A22" {...st} />
    <rect x={560} y={640} width={260} height={230} fill="#5B4032" opacity={0.7} />
  </g>
);

export const FacadeRail: React.FC = () => (
  <g>
    <rect x={280} y={800} width={760} height={24} fill="#4A4A55" {...st} />
    {Array.from({length: 13}).map((_, i) => <rect key={i} x={300 + i * 58} y={824} width={12} height={90} fill="#4A4A55" />)}
    <rect x={280} y={914} width={760} height={34} fill="#6A6A75" {...st} />
    <rect y={948} width={1920} height={132} fill="#555560" />
  </g>
);

export const MGBackground: React.FC<{dark?: boolean}> = ({dark}) => (
  <g>
    <defs>
      <radialGradient id="mg" cx="0.5" cy="0.45" r="0.8">
        <stop offset="0" stopColor={dark ? '#1E3A6E' : '#FFF8EA'} />
        <stop offset="1" stopColor={dark ? '#0B1230' : '#F2D9AE'} />
      </radialGradient>
    </defs>
    <rect width={1920} height={1080} fill="url(#mg)" />
  </g>
);
