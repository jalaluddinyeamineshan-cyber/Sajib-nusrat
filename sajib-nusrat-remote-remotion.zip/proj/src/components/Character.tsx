import React, {useId} from 'react';
import {useCurrentFrame} from 'remotion';
import {OUTLINE, SW} from '../theme';
import {useTalking} from './SceneCtx';
import type {Who} from '../data/timeline';
import {Shawl, Towel} from './Props';

export type Expr = 'neutral' | 'happy' | 'laugh' | 'angry' | 'sad' | 'surprised' | 'think' | 'smug';
export type Pt = {x: number; y: number};
export type Hands = {L: Pt; R: Pt; aL: number; aR: number};

export type CharProps = {
  who: Who;
  x: number;
  y: number;
  scale?: number;
  flip?: boolean;
  sit?: boolean;
  walk?: boolean;
  expr?: Expr;
  armL?: [number, number];
  armR?: [number, number];
  lean?: number;
  crouch?: number;
  headTilt?: number;
  jitter?: number;
  look?: [number, number];
  shawl?: boolean;
  towel?: boolean;
  clipY?: number;
  talking?: boolean;
  opacity?: number;
  hold?: (h: Hands) => React.ReactNode;
};

type Look = {
  skin: string; skinD: string; hair: string; top: string; topD: string; bottom: string; shoe: string;
  sh: number; tw: number; hx: number; hy: number; ex: number; lx: number; lw: number; aw: number;
};

const LOOKS: Record<Who, Look> = {
  sajib: {skin: '#C99763', skinD: '#A87846', hair: '#1E1E1E', top: '#A3A9B0', topD: '#868C93', bottom: '#2E5CA8', shoe: '#FFFFFF', sh: 72, tw: 156, hx: 86, hy: 84, ex: 34, lx: 36, lw: 62, aw: 36},
  nusrat: {skin: '#F7DCC6', skinD: '#E0B898', hair: '#1E1E1E', top: '#98D6A4', topD: '#78BB86', bottom: '#8CCB98', shoe: '#7A5642', sh: 58, tw: 124, hx: 72, hy: 88, ex: 30, lx: 28, lw: 48, aw: 28},
  rehana: {skin: '#D8A47A', skinD: '#B9825A', hair: '#9A9A9A', top: '#7B4BA0', topD: '#60377F', bottom: '#7B4BA0', shoe: '#8A5A3A', sh: 92, tw: 200, hx: 94, hy: 88, ex: 36, lx: 44, lw: 70, aw: 40},
};

type ExDef = {eo: number; browY: number; tilt: number; mouth: string; arc?: boolean; blush?: boolean; look?: [number, number]};
const EX: Record<Expr, ExDef> = {
  neutral: {eo: 1, browY: 0, tilt: 0, mouth: 'lite'},
  happy: {eo: 1, browY: -3, tilt: -3, mouth: 'smile', blush: true},
  laugh: {eo: 0, browY: -8, tilt: -4, mouth: 'laugh', arc: true, blush: true},
  angry: {eo: 0.75, browY: 6, tilt: 16, mouth: 'frown'},
  sad: {eo: 0.95, browY: -8, tilt: -14, mouth: 'frown'},
  surprised: {eo: 1.25, browY: -18, tilt: 0, mouth: 'o'},
  think: {eo: 1, browY: -4, tilt: -6, mouth: 'flat', look: [8, -8]},
  smug: {eo: 0.6, browY: 0, tilt: 4, mouth: 'smirk'},
};

const HIP = -195;
const L1 = 100;
const L2 = 95;
const rad = (d: number) => (d * Math.PI) / 180;
const st = {stroke: OUTLINE, strokeWidth: SW, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

const armPts = (sx: number, sy: number, a: number, b: number) => {
  const ex = sx + L1 * Math.sin(rad(a));
  const ey = sy + L1 * Math.cos(rad(a));
  const hx = ex + L2 * Math.sin(rad(a + b));
  const hy = ey + L2 * Math.cos(rad(a + b));
  return {hx, hy};
};

/** Screen position of a hand (ignores lean/headTilt) so scenes can attach cables, plugs, etc. */
export const handScreen = (o: {who: Who; x: number; y: number; scale?: number; flip?: boolean; sit?: boolean; crouch?: number; arm: [number, number]; side: 'L' | 'R'}): Pt => {
  const lk = LOOKS[o.who];
  const sy = -405 + (o.sit ? 85 : 0) + (o.crouch ?? 0);
  const sx = o.side === 'L' ? -lk.sh : lk.sh;
  const {hx, hy} = armPts(sx, sy, o.arm[0], o.arm[1]);
  const sc = o.scale ?? 1;
  return {x: o.x + hx * sc * (o.flip ? -1 : 1), y: o.y + hy * sc};
};

const Arm: React.FC<{sx: number; sy: number; a: number; b: number; lk: Look; sleeveU: number; sleeveF: number; sleeve: string}> = ({sx, sy, a, b, lk, sleeveU, sleeveF, sleeve}) => {
  const aw = lk.aw;
  const fw = aw * 0.9;
  return (
    <g transform={`translate(${sx},${sy}) rotate(${-a})`}>
      <rect x={-aw / 2} y={-aw / 2} width={aw} height={L1 + aw / 2} rx={aw / 2} fill={lk.skin} {...st} />
      <rect x={-aw / 2} y={-aw / 2} width={aw} height={sleeveU} rx={aw / 2} fill={sleeve} {...st} />
      <g transform={`translate(0,${L1}) rotate(${-b})`}>
        <rect x={-fw / 2} y={-fw / 2} width={fw} height={L2 + fw / 2} rx={fw / 2} fill={lk.skin} {...st} />
        {sleeveF > 0 && <rect x={-fw / 2} y={-fw / 2} width={fw} height={sleeveF} rx={fw / 2} fill={sleeve} {...st} />}
      </g>
    </g>
  );
};

const Hand: React.FC<{p: Pt; ang: number; lk: Look}> = ({p, ang, lk}) => (
  <g transform={`translate(${p.x},${p.y}) rotate(${-ang})`}>
    <ellipse cx={lk.aw * 0.38} cy={-lk.aw * 0.1} rx={lk.aw * 0.2} ry={lk.aw * 0.3} fill={lk.skin} {...st} />
    <circle r={lk.aw * 0.62} fill={lk.skin} {...st} />
  </g>
);

const Eye: React.FC<{cx: number; cy: number; side: -1 | 1; who: Who; ex: ExDef; blink: boolean; look: [number, number]; lk: Look}> = ({cx, cy, side, who, ex, blink, look, lk}) => {
  const rx = who === 'rehana' ? 15 : who === 'nusrat' ? 23 : 21;
  const ry0 = who === 'rehana' ? 15 : who === 'nusrat' ? 21 : 23;
  const pr = who === 'rehana' ? 10 : who === 'nusrat' ? 13 : 14;
  const ry = ry0 * ex.eo;
  const closed = blink || ex.eo < 0.2;
  const lx = Math.max(-5, Math.min(5, look[0]));
  const ly = Math.max(-5, Math.min(5, look[1]));
  return (
    <g>
      {ex.arc ? (
        <path d={`M${cx - rx} ${cy + 4} Q${cx} ${cy - rx * 1.2} ${cx + rx} ${cy + 4}`} fill="none" stroke={OUTLINE} strokeWidth={5.5} strokeLinecap="round" />
      ) : closed ? (
        <path d={`M${cx - rx} ${cy} Q${cx} ${cy + 7} ${cx + rx} ${cy}`} fill="none" stroke={OUTLINE} strokeWidth={5} strokeLinecap="round" />
      ) : (
        <>
          <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="#FFFFFF" {...st} />
          <circle cx={cx + lx} cy={cy + ly} r={Math.min(pr * (ex.eo > 1.1 ? 0.8 : 1), ry)} fill="#141414" />
          <circle cx={cx + lx + pr * 0.35} cy={cy + ly - pr * 0.35} r={pr * 0.28} fill="#fff" />
        </>
      )}
      {who === 'nusrat' && (
        <>
          <path d={`M${cx - rx - 1} ${cy + 3} Q${cx} ${cy + ry + 9} ${cx + rx + 1} ${cy + 3}`} fill="none" stroke={OUTLINE} strokeWidth={4} strokeLinecap="round" />
          {[0, 1, 2].map((i) => (
            <line key={i} x1={cx + side * (rx * 0.55 + i * 7)} y1={cy - ry * 0.85 + i * 2} x2={cx + side * (rx * 0.85 + i * 9 + 6)} y2={cy - ry - 8 + i * 3} stroke={OUTLINE} strokeWidth={3} strokeLinecap="round" />
          ))}
        </>
      )}
      {who === 'rehana' && (
        <path d={`M${cx + side * (rx + 7)} ${cy - 2} q${side * 8} -2 ${side * 12} -10 M${cx + side * (rx + 7)} ${cy + 3} q${side * 9} 1 ${side * 13} -3`} fill="none" stroke={lk.skinD} strokeWidth={2.8} strokeLinecap="round" />
      )}
    </g>
  );
};

const mouthEl = (kind: string, who: Who) => {
  const dark = '#7A1F26';
  const line = {fill: 'none', stroke: OUTLINE, strokeWidth: 4.2, strokeLinecap: 'round' as const};
  switch (kind) {
    case 'lite':
      return <path d="M-22 -456 Q0 -444 22 -456" {...line} />;
    case 'smile':
      return <path d="M-30 -460 Q0 -428 30 -460" {...line} />;
    case 'flat':
      return <path d="M-20 -452 L20 -452" {...line} />;
    case 'frown':
      return <path d="M-24 -444 Q0 -464 24 -444" {...line} />;
    case 'smirk':
      return <path d="M-22 -450 Q8 -446 26 -466" {...line} />;
    case 'o':
      return <ellipse cx={0} cy={-448} rx={12} ry={16} fill={dark} {...st} />;
    case 'small':
      return <ellipse cx={0} cy={-452} rx={15} ry={8} fill={dark} {...st} />;
    case 'mid':
      return <ellipse cx={0} cy={-450} rx={18} ry={13} fill={dark} {...st} />;
    case 'big':
      return (
        <g>
          <ellipse cx={0} cy={-448} rx={21} ry={20} fill={dark} {...st} />
          <ellipse cx={0} cy={-438} rx={12} ry={7} fill="#E8737C" />
        </g>
      );
    case 'laugh':
      return (
        <g>
          <path d="M-36 -464 Q0 -396 36 -464 Z" fill={dark} {...st} />
          <path d="M-30 -463 Q0 -452 30 -463 L28 -458 Q0 -447 -28 -458 Z" fill={who === 'rehana' ? '#F5F0E6' : '#FFFFFF'} />
          <ellipse cx={0} cy={-436} rx={13} ry={6} fill="#E8737C" />
        </g>
      );
    default:
      return null;
  }
};

export const Character: React.FC<CharProps> = (p) => {
  const frame = useCurrentFrame();
  const talkCtx = useTalking(p.who);
  const talking = p.talking ?? talkCtx;
  const lk = LOOKS[p.who];
  const exName = p.expr ?? 'neutral';
  const ex = EX[exName];
  const sc = p.scale ?? 1;
  const sit = !!p.sit;
  const walk = !!p.walk;
  const crouch = p.crouch ?? 0;
  const phase = p.who === 'sajib' ? 0 : p.who === 'nusrat' ? 1.7 : 3.1;
  const swing = walk ? Math.sin(frame * 0.4) : 0;
  const bob = walk ? -Math.abs(Math.sin(frame * 0.4)) * 8 : Math.sin(frame / 14 + phase) * 3;
  const jx = p.jitter ? Math.sin(frame * 2.1) * p.jitter : 0;
  const jy = p.jitter ? Math.cos(frame * 2.7) * p.jitter * 0.6 : 0;
  const armL = p.armL ?? [-6, -4];
  const armR = p.armR ?? [6, 4];
  const aL = armL[0] + 20 * swing;
  const aR = armR[0] - 20 * swing;
  const blink = (frame + Math.round(phase * 20)) % 96 < 4;
  const clipId = 'clip' + useId().replace(/:/g, '');

  // mouth choice
  let mouth = ex.mouth;
  if (talking && exName !== 'laugh') mouth = ['small', 'big', 'mid', 'small', 'big'][Math.floor(frame / 4) % 5];
  const talkBrow = talking ? Math.sin(frame * 0.6) * 4 : 0;
  const lookV = p.look ?? ex.look ?? [0, 0];

  const shY = -405 + (sit ? 85 : 0) + crouch + bob;
  const upperT = `translate(0 ${(sit ? 85 : 0) + crouch + bob}) rotate(${p.lean ?? 0} 0 ${HIP})`;
  const sY = -405;
  const handL = armPts(-lk.sh, sY, aL, armL[1]);
  const handR = armPts(lk.sh, sY, aR, armR[1]);
  const hands: Hands = {L: {x: handL.hx, y: handL.hy}, R: {x: handR.hx, y: handR.hy}, aL: aL + armL[1], aR: aR + armR[1]};
  void shY;

  const sleeveU = p.who === 'sajib' ? 52 : p.who === 'nusrat' ? 100 : 70;
  const sleeveF = p.who === 'nusrat' ? 30 : 0;
  const bodyBottom = p.who === 'nusrat' ? -140 : -185;
  const bodyH = bodyBottom + 440;

  // ---- legs ----
  const legs = () => {
    if (sit) {
      const lxs = [0, 16];
      return (
        <g>
          {lxs.map((dx, i) => (
            <g key={i} opacity={i === 0 ? 1 : 0.96}>
              <rect x={dx - 10} y={-110 - lk.lw / 2 + i * 6} width={140} height={lk.lw} rx={lk.lw / 2} fill={i ? lk.bottom : lk.bottom} {...st} />
              <rect x={dx + 130 - lk.lw / 2} y={-110 - lk.lw / 2 + i * 6} width={lk.lw} height={118 - i * 6} rx={lk.lw / 2} fill={lk.bottom} {...st} />
              {foot(dx + 132, -16 + i * 2, 0)}
            </g>
          ))}
        </g>
      );
    }
    const k = (195 - crouch) / 195;
    return (
      <g transform={`scale(1 ${k})`}>
        {p.who === 'rehana' ? (
          <>
            {[-26, 26].map((x) => <g key={x}>{foot(x, -8, 0)}</g>)}
            <path d={`M-100 -240 L-124 -14 Q0 6 124 -14 L100 -240 Z`} fill={lk.top} {...st} />
            <path d="M-70 -200 Q-20 -120 -60 -30 M10 -210 Q50 -120 30 -22 M70 -190 Q95 -110 82 -26" fill="none" stroke={lk.topD} strokeWidth={5} />
            <path d="M-124 -26 Q0 -6 124 -26" fill="none" stroke="#F2C14E" strokeWidth={9} />
          </>
        ) : (
          [-lk.lx, lk.lx].map((x, i) => {
            const ang = (i === 0 ? 22 : -22) * swing;
            return (
              <g key={x} transform={`translate(${x} ${HIP}) rotate(${ang})`}>
                <rect x={-lk.lw / 2} y={-14} width={lk.lw} height={190} rx={lk.lw / 2} fill={lk.bottom} {...st} />
                {p.who === 'sajib' && <line x1={-lk.lw / 2 + 8} y1={10} x2={-lk.lw / 2 + 8} y2={165} stroke="#fff" strokeWidth={4} />}
                <g transform={`translate(0 ${-HIP})`}>{foot(0, -8, 0)}</g>
              </g>
            );
          })
        )}
      </g>
    );
  };

  const foot = (fx: number, fy: number, _r: number) => {
    if (p.who === 'sajib') {
      return (
        <g>
          <ellipse cx={fx + 18} cy={fy + 10} rx={56} ry={15} fill="#FFFFFF" {...st} />
          <ellipse cx={fx + 14} cy={fy - 6} rx={36} ry={14} fill={lk.skin} {...st} />
          <path d={`M${fx - 4} ${fy - 16} Q${fx + 16} ${fy - 4} ${fx + 40} ${fy - 16} L${fx + 40} ${fy} Q${fx + 16} ${fy + 8} ${fx - 4} ${fy} Z`} fill="#FFFFFF" {...st} />
        </g>
      );
    }
    return <ellipse cx={fx + 16} cy={fy + 2} rx={44} ry={17} fill={lk.shoe} {...st} />;
  };

  // ---- head ----
  const hx = lk.hx;
  const hy = lk.hy;
  const eY = -518;
  const brY = (p.who === 'nusrat' ? -560 : p.who === 'rehana' ? -558 : -558) + ex.browY + talkBrow;
  const browW = p.who === 'sajib' ? 10 : p.who === 'nusrat' ? 6 : 5;
  const browC = p.who === 'rehana' ? '#777' : '#1E1E1E';
  const tearOn = false;
  void tearOn;

  const head = (
    <g transform={`translate(0 -440) rotate(${p.headTilt ?? 0}) translate(0 440)`}>
      {/* ears */}
      {p.who !== 'nusrat' && [-1, 1].map((s) => <ellipse key={s} cx={s * hx} cy={-512} rx={15} ry={23} fill={lk.skin} {...st} />)}
      {/* head */}
      <ellipse cx={0} cy={-515} rx={hx} ry={hy} fill={lk.skin} {...st} />
      {/* hair */}
      {p.who === 'sajib' && <path d={`M${-hx + 2} -520 Q${-hx - 4} -612 0 -610 Q${hx + 4} -612 ${hx - 2} -520 Q${hx - 14} -566 0 -570 Q${-hx + 14} -566 ${-hx + 2} -520 Z`} fill={lk.hair} {...st} />}
      {p.who === 'nusrat' && (
        <>
          <path d={`M${-hx - 2} -500 Q${-hx - 12} -616 0 -614 Q${hx + 12} -616 ${hx + 2} -500 Q${hx - 8} -560 ${hx - 28} -572 Q${hx - 54} -548 ${-hx + 30} -546 Q${-hx + 12} -540 ${-hx - 2} -500 Z`} fill={lk.hair} {...st} />
        </>
      )}
      {p.who === 'rehana' && (
        <>
          <path d={`M${-hx - 6} -506 Q${-hx - 10} -620 0 -622 Q${hx + 10} -620 ${hx + 6} -506 Q${hx - 6} -566 0 -572 Q${-hx + 6} -566 ${-hx - 6} -506 Z`} fill={lk.top} {...st} />
          <path d={`M${-hx + 2} -540 q-14 20 -8 44 M${hx - 2} -540 q14 20 8 44`} fill="none" stroke="#C9C9C9" strokeWidth={9} strokeLinecap="round" />
        </>
      )}
      {/* glasses (Sajib) */}
      {p.who === 'sajib' && (
        <g fill="none" stroke="#161616" strokeWidth={6}>
          <circle cx={-lk.ex} cy={eY} r={33} fill="rgba(255,255,255,0.16)" />
          <circle cx={lk.ex} cy={eY} r={33} fill="rgba(255,255,255,0.16)" />
          <path d={`M${-lk.ex + 33} ${eY} Q0 ${eY - 10} ${lk.ex - 33} ${eY}`} />
          <path d={`M${-lk.ex - 33} ${eY - 2} L${-hx} ${eY - 4} M${lk.ex + 33} ${eY - 2} L${hx} ${eY - 4}`} />
        </g>
      )}
      {/* cheeks */}
      {(ex.blush || p.who === 'nusrat') && [-1, 1].map((s) => <ellipse key={s} cx={s * (lk.ex + 24)} cy={-470} rx={19} ry={10} fill="#FF7F8E" opacity={ex.blush ? 0.5 : 0.22} />)}
      {/* brows */}
      <path d={`M${-lk.ex - 26} ${brY} L${-lk.ex + 24} ${brY + ex.tilt}`} stroke={browC} strokeWidth={browW} strokeLinecap="round" fill="none" />
      <path d={`M${lk.ex + 26} ${brY} L${lk.ex - 24} ${brY + ex.tilt}`} stroke={browC} strokeWidth={browW} strokeLinecap="round" fill="none" />
      {/* eyes */}
      <Eye cx={-lk.ex} cy={eY} side={-1} who={p.who} ex={ex} blink={blink} look={lookV} lk={lk} />
      <Eye cx={lk.ex} cy={eY} side={1} who={p.who} ex={ex} blink={blink} look={lookV} lk={lk} />
      {/* nose */}
      {p.who === 'sajib' && (
        <g>
          <path d="M-4 -504 Q-12 -484 -10 -478 Q0 -470 12 -478" fill="none" stroke={OUTLINE} strokeWidth={3.6} strokeLinecap="round" strokeLinejoin="round" />
          <ellipse cx={1} cy={-478} rx={13} ry={8} fill={lk.skinD} {...st} />
        </g>
      )}
      {p.who === 'nusrat' && (
        <g>
          <path d="M-2 -505 L-7 -480 Q0 -472 9 -480" fill="none" stroke={OUTLINE} strokeWidth={3.4} strokeLinecap="round" strokeLinejoin="round" />
          <circle cx={9} cy={-481} r={4.6} fill="#F2C14E" stroke={OUTLINE} strokeWidth={1.6} />
        </g>
      )}
      {p.who === 'rehana' && (
        <g>
          <ellipse cx={0} cy={-484} rx={12} ry={10} fill={lk.skinD} {...st} />
          <circle cx={-4} cy={-482} r={2} fill={OUTLINE} />
          <circle cx={4} cy={-482} r={2} fill={OUTLINE} />
        </g>
      )}
      {/* lips */}
      {p.who === 'nusrat' && <ellipse cx={0} cy={-452} rx={27} ry={10} fill="#F08BA2" opacity={0.85} />}
      {p.who === 'rehana' && (
        <g>
          <ellipse cx={0} cy={-452} rx={27} ry={11} fill="#C9524B" {...st} />
          <ellipse cx={0} cy={-452} rx={9} ry={4} fill="#7A1F26" />
        </g>
      )}
      {mouth !== 'lite' || p.who === 'sajib' || p.who === 'nusrat' ? mouthEl(mouth, p.who) : null}
      {/* dimples */}
      {p.who === 'sajib' && (mouth === 'smile' || mouth === 'laugh') && [-1, 1].map((s) => <path key={s} d={`M${s * 44} -462 Q${s * 38} -454 ${s * 44} -446`} fill="none" stroke={lk.skinD} strokeWidth={3.5} strokeLinecap="round" />)}
    </g>
  );

  const hasHold = !!p.hold;

  return (
    <g transform={`translate(${p.x + jx} ${p.y + jy}) scale(${p.flip ? -sc : sc} ${sc})`} opacity={p.opacity ?? 1} clipPath={p.clipY !== undefined ? `url(#${clipId})` : undefined}>
      {p.clipY !== undefined && (
        <clipPath id={clipId}>
          <rect x={-500} y={-900} width={1000} height={900 + p.clipY} />
        </clipPath>
      )}
      <ellipse cx={0} cy={4} rx={150} ry={14} fill="#000" opacity={0.12} />
      {legs()}
      <g transform={upperT}>
        {p.who === 'nusrat' && <rect x={-100} y={-600} width={200} height={230} rx={74} fill={lk.hair} {...st} />}
        {/* torso */}
        <rect x={-lk.tw / 2} y={-440} width={lk.tw} height={bodyH} rx={46} fill={lk.top} {...st} />
        {p.who === 'sajib' && <ellipse cx={0} cy={-270} rx={72} ry={58} fill={lk.top} stroke={OUTLINE} strokeWidth={SW} />}
        {p.who === 'sajib' && <path d="M-26 -440 Q0 -410 26 -440" fill={lk.skin} {...st} />}
        {p.who === 'nusrat' && (
          <>
            <path d="M-30 -440 Q0 -400 30 -440" fill={lk.skin} {...st} />
            <path d="M0 -400 L0 -250 M-26 -300 q26 14 52 0" fill="none" stroke={lk.topD} strokeWidth={4} />
          </>
        )}
        {p.who === 'rehana' && (
          <>
            <path d="M-100 -430 Q0 -330 100 -430 L100 -330 Q0 -250 -100 -330 Z" fill={lk.topD} {...st} />
            <path d="M-30 -440 Q0 -410 30 -440" fill={lk.skin} {...st} />
          </>
        )}
        {p.shawl && <Shawl w={lk.sh} />}
        {p.towel && <Towel />}
        {/* neck */}
        <rect x={-18} y={-470} width={36} height={36} fill={lk.skin} {...st} />
        {head}
        {/* arms */}
        <Arm sx={-lk.sh} sy={sY} a={aL} b={armL[1]} lk={lk} sleeveU={sleeveU} sleeveF={sleeveF} sleeve={p.who === 'rehana' ? lk.top : lk.top} />
        <Arm sx={lk.sh} sy={sY} a={aR} b={armR[1]} lk={lk} sleeveU={sleeveU} sleeveF={sleeveF} sleeve={lk.top} />
        {hasHold && p.hold!(hands)}
        <Hand p={hands.L} ang={hands.aL} lk={lk} />
        <Hand p={hands.R} ang={hands.aR} lk={lk} />
      </g>
    </g>
  );
};
