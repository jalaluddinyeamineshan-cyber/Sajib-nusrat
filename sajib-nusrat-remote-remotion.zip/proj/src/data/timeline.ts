import {FPS, sec} from '../theme';

export type Who = 'sajib' | 'nusrat' | 'rehana';

/** Scene boundaries in seconds (from voice.mp3 + SRT). */
export const SCENE_TIMES = [0, 24.56, 35.4, 46.72, 56.22, 74.18, 91.58, 108.1, 119.16, 144.54, 165.0, 177.0, 181.48];
export const TOTAL_FRAMES = sec(181.48);

export type Dialogue = {
  id: string;
  who: Who;
  kind: 'speech' | 'thought';
  from: number;
  to: number;
  lines?: string[];
  icon?: 'notebook' | 'glasses';
  x: number; // bubble top-left
  y: number;
  w: number;
  h: number;
  tx: number; // tail tip
  ty: number;
};

export const DIALOGUES: Dialogue[] = [
  {id: 'd1', who: 'nusrat', kind: 'speech', from: 0.14, to: 5.0, lines: ['ওগো শুনছো? রিমোটটা দাও তো।', 'নাটকটা শুরু হয়ে গেল যে।'], x: 560, y: 50, w: 760, h: 170, tx: 940, ty: 290},
  {id: 'd2', who: 'sajib', kind: 'speech', from: 20.42, to: 24.56, lines: ['আরে বাবা, আর একটা ওভার।', 'শেষটা অন্তত দেখতে দাও।'], x: 120, y: 90, w: 760, h: 170, tx: 520, ty: 372},
  {id: 'd3', who: 'sajib', kind: 'speech', from: 80.7, to: 82.6, lines: ['এ কি, টিভি বন্ধ করে দিলে?'], x: 180, y: 130, w: 720, h: 110, tx: 340, ty: 300},
  {id: 'd4', who: 'nusrat', kind: 'speech', from: 83.1, to: 87.1, lines: ['আমি কিছু করিনি। তোমার রিমোট', 'তোমার বালিশই সামলাক।'], x: 300, y: 60, w: 840, h: 170, tx: 650, ty: 372},
  {id: 'd5', who: 'sajib', kind: 'speech', from: 105.1, to: 108.1, lines: ['শোনো, চলো না আজ ছাদে', 'গিয়ে তারা দেখি।'], x: 330, y: 60, w: 700, h: 170, tx: 700, ty: 290},
  {id: 'd6', who: 'nusrat', kind: 'speech', from: 121.4, to: 125.4, icon: 'notebook', x: 1090, y: 120, w: 300, h: 210, tx: 1250, ty: 372},
  {id: 'd7', who: 'sajib', kind: 'speech', from: 127.8, to: 133.7, icon: 'glasses', x: 740, y: 110, w: 300, h: 220, tx: 1030, ty: 372},
  {id: 'd8', who: 'sajib', kind: 'speech', from: 149.86, to: 152.18, lines: ['নাও গো, আজ তুমিই ঠিক করো।'], x: 60, y: 120, w: 760, h: 110, tx: 380, ty: 290},
  {id: 'd9', who: 'nusrat', kind: 'speech', from: 158.98, to: 165.0, lines: ['আজকেও ছাদে চলো না গো। তারাগুলো তো পালিয়ে যাচ্ছে না।', 'কিন্তু আমি তোমার গল্প শুনতে চাই।'], x: 340, y: 40, w: 1160, h: 170, tx: 1330, ty: 290},
];

/** Stamps / cards shown on screen (caption is hidden while they are visible). */
export const STAMPS = {
  goodMan: {from: 53.9, to: 56.2},
  weird: {from: 64.4, to: 66.74},
  rate: {from: 43.6, to: 46.72},
  never: {from: 140.9, to: 144.5},
};

/** Motion-graphics scenes (cards carry the text, no bottom caption). */
const MG: [number, number][] = [
  [24.56, 35.4],
  [165.0, 181.48],
];

export const noCaptionRanges: [number, number][] = [
  ...DIALOGUES.map((d) => [d.from, d.to] as [number, number]),
  ...Object.values(STAMPS).map((s) => [s.from, s.to] as [number, number]),
  ...MG,
];

export const hideCaption = (t: number) => noCaptionRanges.some(([a, b]) => t >= a && t < b);
export const secToFrame = (s: number) => Math.round(s * FPS);
