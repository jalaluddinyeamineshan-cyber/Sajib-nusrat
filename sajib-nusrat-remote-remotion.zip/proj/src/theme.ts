import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const {fontFamily} = loadFont('normal', {
  weights: ['500', '600', '700'],
  subsets: ['bengali', 'latin'],
});

export const W = 1920;
export const H = 1080;
export const FPS = 30;
export const OUTLINE = '#222222';
export const SW = 2.5;
export const FLOOR = 900;
export const sec = (s: number) => Math.round(s * FPS);
export const AUDIO_SECONDS = 181.48;
