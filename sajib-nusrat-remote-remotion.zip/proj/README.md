# সজীব ও নুসরাতের রিমোটের গল্প (Remotion প্রজেক্ট)

## চালানোর ধাপ
1. `npm install`
2. `npx remotion studio`   (প্রিভিউ — ব্রাউজারে খুলবে, Composition: Main)
3. `npx remotion render Main out/video.mp4`   (রেন্ডার)

নোট: ফন্ট (Hind Siliguri) প্রথমবার ইন্টারনেট থেকে লোড হয়, তাই প্রথম প্রিভিউ/রেন্ডারের সময় নেট চালু রাখুন।

## ফাইল কাঠামো
- `public/voice.mp3`, `public/voice.srt` — ভয়েসওভার ও সাবটাইটেল
- `src/data/timeline.ts` — সিনের সময়, সংলাপ বাবল, স্ট্যাম্পের সময় (সব এখান থেকে বদলানো যায়)
- `src/data/captions.ts` — SRT থেকে বানানো নিচের ক্যাপশন
- `src/components/Character.tsx` — সজীব / নুসরাত / চাচি রেহানা (চোখ, ভুরু, নাক, মুখ, হাত, পা)
- `src/components/Backgrounds.tsx` — ড্রয়িং রুম, শোবার ঘর, ছাদ, বারান্দা, ভবনের সামনের দিক
- `src/scenes/Scenes1.tsx` (সিন ১–৪), `Scenes2.tsx` (৫–৮), `Scenes3.tsx` (৯–১২)
